
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Bienvenue sur Click&amp;Cloud</title>
<meta name="viewport" content="width=device-width">
<link href="public/optimum/css/f1902cfa8c412a28ee0fe637a92a072d.out.css"
	rel="stylesheet" type="text/css" />
<!--[if lte IE 7]><link href="public/optimum/css/533a94db90b43e013693222fbbc3e04b.addon.mhtml.css" rel="stylesheet" type="text/css"/><![endif]-->
<!--[if gt IE 7]><!-->
<link
	href="public/optimum/css/653b3d63a5c93809593e6dcfe5b68a31.addon.b64.css"
	rel="stylesheet" type="text/css" />
<!--<![endif]-->
</head>

<body>
	<div class="page">
		<div class="header">
			<div class="logo">
				<div class="cloud"></div>
			</div>
			<h1>BIENVENUE</h1>
			<h2></h2>
			<h3 class="blue">Votre application est h&eacute;berg&eacute;e sur Click&amp;Cloud !</h3>

			<!--<a id="header-link" href="http://jelastic.com/" target="_blank"
				class="powered-by"></a>-->

			<noscript>
				<h1 class="visible">BIENVENUE</h1>
				<a href="http://app.clicketcloud.com/" target="_blank"
					class="visible powered-by"></a>
			</noscript>

		</div>
		<div class="share">
			<div class="separator top"></div>
			<div class="social">
					<a target="_blank" name="linkedin"
				    href="https://www.linkedin.com/company/owentis" 
					class="linkedin"></a>                        
					<a target="_blank" name="viadeo"
				    href="http://fr.viadeo.com/fr/company/owentis" 
					class="viadeo"></a>
					<a target="_blank" name="twitter"
				    href="https://twitter.com/Owentis" 
					class="twitter"></a>
					<a target="_blank" name="facebook"
				    href="https://www.facebook.com/Groupe-Ozitem-214935588593562/timeline/" 
					class="facebook"></a>
			</div>
			<div class="separator bottom"></div>
		</div>
		
		<div class="links-block">
			<div class="title">Liens utiles</div>
			<div class="c1">
				<ul class="links">
					<li><a target="_blank"
						href="http://www.clicketcloud.com/faq.html">FAQ Click&amp;Cloud</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/php-application-server-config">Toutes les fonctionnalit&eacute;s PHP</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/php-extensions">Configurer les extensions PHP</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/whole-project-deploying">D&eacute;ployer un projet entier</a></li>
				</ul>
			</div>
			<div class="c2">
				<ul class="links">
					<li><a target="_blank"
						href="http://docs.jelastic.com/ssh-access">Acc&eacute;der en SSH</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/php-git-svn">D&eacute;ployer ses projets via GIT ou SVN</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/app-packaging">Packager une application</a></li>
					<li><a target="_blank"
						href="http://docs.jelastic.com/pricing-model">FAQ sur les tarifs</a></li>
				</ul>
			</div>
		</div>
		<div class="footer">
			&copy; <a id="footer-link" href="http://www.clicketcloud.com/"
				target="_blank">Click&amp;Cloud</a>,



			<?php echo date("Y") ?>
			Tous droits r&eacute;serv&eacute;s.
		</div>
	</div>
	<script type="text/javascript" duris:nomerge=1>
		(function(e, a, f) {
			var c, b = e.getElementsByTagName(a)[0];
			if (e.getElementById(f)) {
				return
			}
			c = e.createElement(a);
			c.id = f;
			c.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
			b.parentNode.insertBefore(c, b)
		}(document, "script", "facebook-jssdk"));
		var _gaq = _gaq || [];
		_gaq.push([ "_setAccount", "UA-24049059-10" ]);
		_gaq.push([ "_setDomainName", "example.com" ]);
		_gaq.push([ "_setAllowLinker", true ]);
		_gaq.push([ "_trackPageview" ]);
		(function() {
			var b = document.createElement("script");
			b.type = "text/javascript";
			b.async = true;
			b.src = ("https:" == document.location.protocol ? "https://ssl"
					: "http://www")
					+ ".google-analytics.com/ga.js";
			var a = document.getElementsByTagName("script")[0];
			a.parentNode.insertBefore(b, a)
		})();
	</script>
	<script src="public/optimum/js/f0ec53c40f3f25833ddf8b6ef147fe8f.out.js"
		type="text/javascript"></script>
</body>
</html>
