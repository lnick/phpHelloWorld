package daemon

import (
	"github.com/docker/docker/runconfig"
)

func mergeLxcConfIntoOptions(hostConfig *runconfig.HostConfig) ([]string, error) {
	return nil, nil
}
