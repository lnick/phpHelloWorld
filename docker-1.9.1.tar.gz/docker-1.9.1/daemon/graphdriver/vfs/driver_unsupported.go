// +build !daemon

package vfs
