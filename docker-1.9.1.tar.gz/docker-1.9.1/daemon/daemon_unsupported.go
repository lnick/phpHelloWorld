// +build !linux,!freebsd,!windows

package daemon

const platformSupported = false
