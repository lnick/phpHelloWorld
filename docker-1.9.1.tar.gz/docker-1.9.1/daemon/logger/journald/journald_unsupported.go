// +build !linux

package journald
