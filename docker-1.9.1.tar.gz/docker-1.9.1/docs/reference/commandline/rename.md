<!--[metadata]>
+++
title = "rename"
description = "The rename command description and usage"
keywords = ["rename, docker, container"]
[menu.main]
parent = "smn_cli"
+++
<![end-metadata]-->

# rename

    Usage: docker rename [OPTIONS] OLD_NAME NEW_NAME

    Rename a container

      --help=false    Print usage

The `docker rename` command allows the container to be renamed to a different name.
