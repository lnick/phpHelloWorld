// +build daemon

package docker

// notifySystem sends a message to the host when the server is ready to be used
func notifySystem() {
}
