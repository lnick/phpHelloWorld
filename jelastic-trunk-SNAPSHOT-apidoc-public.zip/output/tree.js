
		Docs.classData ={"id":"apidocs","iconCls":"icon-pkg","text":"Jelastic","singleClickExpand":true,"expanded":true,"children":[
                {"id":"pkg-Billing","text":"Billing","iconCls":"icon-pkg","cls":"package","singleClickExpand":true, children:[
                {"href":"output/billing.Account.html","text":"Account","id":"billing.Account","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				]}
				,
                {"id":"pkg-Environment","text":"Environment","iconCls":"icon-pkg","cls":"package","singleClickExpand":true, children:[
                {"href":"output/environment.Binder.html","text":"Binder","id":"environment.Binder","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Build.html","text":"Build","id":"environment.Build","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Control.html","text":"Control","id":"environment.Control","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.File.html","text":"File","id":"environment.File","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Tracking.html","text":"Tracking","id":"environment.Tracking","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Trigger.html","text":"Trigger","id":"environment.Trigger","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Vcs.html","text":"Vcs","id":"environment.Vcs","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				,
                {"href":"output/environment.Windows.html","text":"Windows","id":"environment.Windows","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				]}
				]};
        Docs.icons = {
        
			"billing.Account":"icon-cls"
			,
			"environment.Binder":"icon-cls"
			,
			"environment.Build":"icon-cls"
			,
			"environment.Control":"icon-cls"
			,
			"environment.File":"icon-cls"
			,
			"environment.Tracking":"icon-cls"
			,
			"environment.Trigger":"icon-cls"
			,
			"environment.Vcs":"icon-cls"
			,
			"environment.Windows":"icon-cls"
			};
    