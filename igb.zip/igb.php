<?php
abstract class SerializeTest {
    const COUNT_LOOPS = 1000;
    const ARRAYS_SIZE = 100;
    
    const LOG = false;

    public final function run() {
        $this->time = array();
        $this->size = array();
        $data = $this->makeData();
        $functions = array(
            array('serialize', 'unserialize'),
            array('igbinary_serialize', 'igbinary_unserialize'),
        );
        foreach ($functions as $ff) {
            $fs = $ff[0];
            $fu = $ff[1];
            $result = $this->testFunction($data, $fs);
            $this->testFunction($result, $fu);
            $this->size[$fs] = strlen($result);
            if (self::LOG) {
                $filename = get_class($this).'-'.$fs.'.log';
                file_put_contents($filename, $result);
            }
        }
        return true;
    }
    
    public final function drawResult() {
        if (!$this->name) {
            throw new RuntimeException(__CLASS__.' name is not defined');
        }
        echo '<h1>'.$this->name.'</h1>';
        $timeSer    = number_format($this->time['serialize'] * 1000, 0, ',', ' ').' ms';
        $timeISer   = number_format($this->time['igbinary_serialize'] * 1000, 0, ',', ' ').' ms';;
        $timeUnser  = number_format($this->time['unserialize'] * 1000, 0, ',', ' ').' ms';
        $timeIUnser = number_format($this->time['igbinary_unserialize'] * 1000, 0, ',', ' ').' ms';
        $size       = number_format($this->size['serialize'], 0, ',', ' ');
        $sizeI      = number_format($this->size['igbinary_serialize'], 0, ',', ' ');
        $timeSerP   = number_format(($this->time['serialize'] / $this->time['igbinary_serialize']), 1, ',', ' ');
        $timeUnserP = number_format(($this->time['unserialize'] / $this->time['igbinary_unserialize']), 1, ',', ' ');
        $sizeP      = number_format(($this->size['serialize'] / $this->size['igbinary_serialize']), 1, ',', ' ');
        $sizeEl     = number_format(($this->size['serialize'] / self::ARRAYS_SIZE), 1, ',', ' ');
        $sizeIEl    = number_format(($this->size['igbinary_serialize'] / self::ARRAYS_SIZE), 1, ',', ' ');
        echo
            '<table>'.
                '<tr><td></td><td><b>Serialize</b></td><td><b>Igbinary</b></td><td>/</td></tr>'.
                '<tr><td><b>Time ser</b></td><td>'.$timeSer.'</td><td>'.$timeISer.'</td><td>'.$timeSerP.'</td></tr>'.
                '<tr><td><b>Time unser</b></td><td>'.$timeUnser.'</td><td>'.$timeIUnser.'</td><td>'.$timeUnserP.'</td></tr>'.
                '<tr><td><b>Size</b></td><td>'.$size.'</td><td>'.$sizeI.'</td><td>'.$sizeP.'</td></tr>'.
                '<tr><td><b>Bytes / El<b></td><td>'.$sizeEl.'</td><td>'.$sizeIEl.'</td><td></td></tr>'.                
            '</table>'; 
        return true;
    }
    
    protected function makeData() {
        $data = array();
        for ($i = 0; $i < self::ARRAYS_SIZE; $i++) {
            $data[] = $this->makeElementData();
        }
        return $data;
    }
    
    abstract protected function makeElementData();
    
    private final function testFunction($data, $functionName) {
        $mt = microtime(true);
        for ($i = 0; $i < self::COUNT_LOOPS; $i++) {
            $result = $functionName($data);
        }
        $mt = microtime(true) - $mt;
        $this->time[$functionName] = $mt;
        return $result;
    }

    
    protected $name;    
    
    private $time;
    private $size;
}

final class SerializeTestInteger extends SerializeTest {

    protected function makeElementData() {
        return mt_rand(0, 2000000000);
    }

    protected $name = 'Integer';
}

final class SerializeTestIntegerSmall extends SerializeTest {

    protected function makeElementData() {
        return mt_rand(0, 100);
    }

    protected $name = 'Integer Small';
}

final class SerializeTestIntegerBig extends SerializeTest {

    protected function makeElementData() {
        return mt_rand(1000000000, 2000000000);
    }

    protected $name = 'Integer Big';
}

final class SerializeTestFloat extends SerializeTest {

    protected function makeElementData() {
        return (mt_rand(0, 100) / mt_rand(1, 100));
    }

    protected $name = 'Float';
}

class SerializeTestString extends SerializeTest {

    const STRING_LENGTH = 15;

    protected function makeElementData() {        
        return substr(md5(mt_rand(0, 10000)), 0, self::STRING_LENGTH);
    }

    protected $name = 'String';
}

final class SerializeTestStringKeys extends SerializeTestString {

    const KEY_LENGTH = 10;

    protected function makeData() {
        $data = array();
        for ($i = 0; $i < self::ARRAYS_SIZE; $i++) {
            $key = substr(md5(mt_rand(0, 10000)), 0, self::KEY_LENGTH);
            $data[$key] = $this->makeElementData();
        }
        return $data;
    }

    protected $name = 'String-Keys';
}

$tests = array(
    new SerializeTestInteger(),
    new SerializeTestIntegerSmall(),
    new SerializeTestIntegerBig(),
    new SerializeTestFloat(),
    new SerializeTestString(),
    new SerializeTestStringKeys(),
);

foreach ($tests as $test) {
    $test->run();
    $test->drawResult();
}
?>
