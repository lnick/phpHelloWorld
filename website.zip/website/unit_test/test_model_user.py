import unittest
from flask.ext.login import login_user, current_user, logout_user
from email_validator import EmailSyntaxError
from testsetup import TestCaseBasic
from app.models import User, AnonymousUser
from app.auth.views import load_user
import app.exception as e
from app.utilscripts.usertables import create_user_data_tables


class TestCreateAccount(TestCaseBasic):

    new_user = User(email="z@gmail.com", password="whisky4")

    def test_user_constructor(self):
        new_user = User(email="some_email@gmail.com", password="some_password")

    def test_create_account(self):
        self.assertRaises(e.NoSuchUserError, User.get_user_by_email, "z@gmail.com")
        User.create_account(self.new_user)
        user = User.get_user_by_email("z@gmail.com")
        self.assertEqual("z@gmail.com", user.email)
        user.check_password("whisky4")

    def test_get_user_by_email(self):
        user = User.get_user_by_email("j@gmail.com")
        self.assertEqual(1, user.id)

    def test_get_user_by_email_capital_letters(self):
        user = User.get_user_by_email("J@gMaIL.coM")
        self.assertEqual(1, user.id)
        user = User.get_user_by_email("J@GMAIL.com")
        self.assertEqual(1, user.id)

    def test_check_user_password(self):
        user = User.get_user_by_id(1)
        user.check_password("whisky1")
        self.assertRaises(e.BadPasswordError, user.check_password, "wHiSKy1")
        self.assertRaises(e.BadPasswordError, user.check_password, "wrong_password")


class TestUserLogin(TestCaseBasic):

    new_user = User(email="k@gmail.com", password="whisky4")

    def tearDown(self):
        self.app.get('/logout')
        logout_user()

    def test_user_constructor(self):
        self.assertEqual(self.new_user.email, "k@gmail.com")
        self.new_user.check_password("whisky4")

    def test_user_string_representation(self):
        user = User.query.filter_by(id=1).one()
        self.assertEqual("<User 1, u'j@gmail.com'>", str(user))

    def test_user_identity(self):
        user_1 = User.query.filter_by(id=1).one()
        user_2 = User.query.filter_by(id=1).one()
        self.assertIs(user_1, user_2)

    def test_user_inequality(self):
        user_1 = User.query.filter_by(id=1).one()
        user_2 = User.query.filter_by(id=2).one()
        self.assertNotEqual(user_1, user_2)

    def test_get_user_by_existing_id(self):
        user = User.get_user_by_id(1)
        self.assertEqual("j@gmail.com", user.email)
        user.check_password("whisky1")

    def test_get_user_by_non_existing_id(self):
        self.assertRaises(e.NoSuchUserError, User.get_user_by_id, 99999)

    def test_user_loader_existing_id(self):
        expected_user = load_user(1)
        actual_user = User.get_user_by_id(1)
        self.assertEqual(expected_user, actual_user)

    def test_user_loader_non_existing_id(self):
        user = load_user(99999)
        self.assertIsNone(user)

    def test_current_user_is_authenticated(self):
        user = User.get_user_by_id(1)
        login_user(user)
        self.assertTrue(current_user.is_authenticated)

    def test_current_user_is_logged_in_user(self):
        user = User.get_user_by_id(1)
        login_user(user)
        self.assertEqual(current_user, user)

    def test_current_user_is_not_authenticated_after_logging_out(self):
        user = User.get_user_by_id(1)
        login_user(user)
        self.assertTrue(current_user.is_authenticated)
        logout_user()
        self.assertFalse(current_user.is_authenticated)

    def test_anyonomous_user_is_not_authenticated(self):
        self.assertFalse(current_user.is_authenticated)


class TestUserWatchlistManipulation(TestCaseBasic):

    def test_is_watching_stock_code(self):
        user = User.get_user_by_id(1)
        self.assertTrue(user.is_watching_stock_code(2))
        self.assertTrue(user.is_watching_stock_code("2"))
        self.assertTrue(user.is_watching_stock_code(6))
        self.assertTrue(user.is_watching_stock_code("6"))
        self.assertFalse(user.is_watching_stock_code(999))
        self.assertFalse(user.is_watching_stock_code("999"))

    def test_add_to_watchlist_stock_code_not_yet_on_watchlist(self):
        user = User.get_user_by_id(1)
        user.add_to_watchlist("0004")
        user.add_to_watchlist(9)
        user.add_to_watchlist("101")
        self.assertTrue(user.is_watching_stock_code(4))
        self.assertTrue(user.is_watching_stock_code(9))
        self.assertTrue(user.is_watching_stock_code(101))

    def test_add_to_watchlist_stock_code_already_on_watchlist(self):
        user = User.get_user_by_id(1)
        self.assertTrue(user.is_watching_stock_code(2))
        self.assertRaises(e.StockCodeAlreadyOnWatchlistError, user.add_to_watchlist, 2)

    def test_add_to_watchlist_invalid_stock_code(self):
        user = User.get_user_by_id(1)
        self.assertRaises(e.NoStockCodeFoundError, user.add_to_watchlist, "invalid stock code")
        self.assertRaises(e.NoStockCodeFoundError, user.add_to_watchlist, "")

    def test_remove_from_watchlist_existing_watched_stock_code(self):
        user = User.get_user_by_id(1)
        self.assertTrue(user.is_watching_stock_code(2))
        user.remove_from_watchlist(2)
        self.assertFalse(user.is_watching_stock_code(2))

    def test_remove_from_watchlist_newly_added_stock_code(self):
        user = User.get_user_by_id(1)
        user.add_to_watchlist(7)
        user.remove_from_watchlist(7)
        self.assertFalse(user.is_watching_stock_code(7))

    def test_remove_from_watchlist_stock_code_not_being_watched(self):
        user = User.get_user_by_id(1)
        self.assertRaises(e.StockCodeNotOnWatchlistError, user.remove_from_watchlist, 9999)

    def test_remove_from_watchlist_invalid_stock_code(self):
        user = User.get_user_by_id(1)
        self.assertRaises(e.StockCodeNotOnWatchlistError, user.remove_from_watchlist, "invalid stock code")
        self.assertFalse(user.is_watching_stock_code("invalid stock code"))

    def test_add_to_and_then_remove_from_watchlist(self):
        user = User.get_user_by_id(1)
        self.assertFalse(user.is_watching_stock_code(100))
        user.add_to_watchlist(100)
        self.assertTrue(user.is_watching_stock_code(100))
        user.remove_from_watchlist(100)
        self.assertFalse(user.is_watching_stock_code(100))

    def test_remove_from_and_then_add_back_to_watchlist(self):
        user = User.get_user_by_id(1)
        self.assertTrue(user.is_watching_stock_code(2))
        user.remove_from_watchlist(2)
        self.assertFalse(user.is_watching_stock_code(2))
        user.add_to_watchlist(2)
        self.assertTrue(user.is_watching_stock_code(2))

    def test_is_user_watching_stock_code(self):
        user = User.get_user_by_id(1)
        self.assertTrue(user.is_watching_stock_code(2))
        self.assertFalse(user.is_watching_stock_code(9999))


class TestValidation(TestCaseBasic):

    def test_validate_email(self):
        User.validate_email("valid@valid.com")
        User.validate_email("valid_email@valid.com")
        User.validate_email("valid.email@valid.com")
        User.validate_email("some.valid.email@valid.com")
        User.validate_email("valid@valid.com.hk")
        User.validate_email("Valid123@valid.com.hk")
        User.validate_email("valid@uk.co")
        User.validate_email("valid@indonesia.co.id")
        User.validate_email("valid@169.com")
        User.validate_email("123@169.com")
        self.assertRaises(e.EmailEmptyError, User.validate_email, None)
        self.assertRaises(e.EmailEmptyError, User.validate_email, "")
        self.assertRaises(EmailSyntaxError, User.validate_email, "@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "@bad_email.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "bad@bad@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, " m@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "m@bad")
        self.assertRaises(EmailSyntaxError, User.validate_email, "\"@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "\"a@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "bad bad@bad.com")
        self.assertRaises(EmailSyntaxError, User.validate_email, "bad@bad bad.com")

    def test_check_if_email_is_already_take(self):
        User.check_if_email_is_already_taken("rare_name@rare_domain.com")
        self.assertRaises(e.EmailAlreadyTakenError, User.check_if_email_is_already_taken, "j@gmail.com")
        self.assertRaises(e.EmailAlreadyTakenError, User.check_if_email_is_already_taken, "J@GMaiL.cOm")

    def test_validate_password(self):
        User.validate_password("password")
        User.validate_password("\"")
        self.assertRaises(e.InvalidPasswordError, User.validate_password, "some_password_that_has_more_than_31_characters")
        self.assertRaises(e.InvalidPasswordError, User.validate_password, "")


class TestSettings(TestCaseBasic):

    def test_change_password(self):
        user = User.get_user_by_email("b@gmail.com")
        user.check_password("whisky3")
        user.change_password("new_password")
        user.check_password("new_password")
        self.assertRaises(e.BadPasswordError, user.check_password, "whisky3")


class TestAnonymousUser(TestCaseBasic):

    def test_anonymous_user_basic_properties(self):
        user = AnonymousUser()
        self.assertTrue(user.is_anonymous)
        self.assertFalse(user.is_authenticated)
        self.assertFalse(user.is_active)
        self.assertIsNone(user.get_id())

    def test_manipulating_watchlist_throws_exception(self):
        user = AnonymousUser()
        self.assertRaises(e.NotYetLoggedInError, user.is_watching_stock_code, 1)
        self.assertRaises(e.NotYetLoggedInError, user.add_to_watchlist, 1)
        self.assertRaises(e.NotYetLoggedInError, user.remove_from_watchlist, 1)
