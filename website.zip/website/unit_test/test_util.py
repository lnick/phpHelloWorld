import unittest
from datetime import datetime, timedelta
from flask import request
from testsetup import TestCaseBasic
from app.util import get_request_data, one_year_later, jsonify_exception, send_email, switch_language
import app.exception as e


class TestUtil(TestCaseBasic):

    def test_get_request_data_get_method(self):
        response = self.app.get('/search?phrase=1&language=C')
        phrase = get_request_data("phrase")
        language = get_request_data("language")
        self.assertEqual(phrase, "1")
        self.assertEqual(language, "C")

    def test_get_request_data_get_method_no_data(self):
        response = self.app.get('/')
        phrase = get_request_data("phrase")
        self.assertIsNone(phrase, None)

    def test_jsonify_exception(self):
        try:
            raise e.BadPasswordError
        except (e.BadPasswordError) as err:
            json = jsonify_exception(err)
        self.assertIn('"exception": "BadPasswordError"', json.data)

    def test_jsonify_exception_with_kwargs(self):
        try:
            raise e.NoSuchUserError
        except (e.NoSuchUserError) as err:
            json = jsonify_exception(err, keyword="some_keyword")
        self.assertIn('"exception": "NoSuchUserError"', json.data)
        self.assertIn('"keyword": "some_keyword"', json.data)

    @unittest.skip("slow")
    def test_send_email(self):
        response = send_email(
            to_address="brianlwh@gmail.com",
            from_address="unit.test@filingHK.com",
            subject="This email is sent during unit tests",
            body_html="<b>The body text is bold.</b>")
        self.assertEqual("Queued. Thank you.", response.json()["message"])
        self.assertEqual(200, response.status_code)

    def test_one_year_later(self):
        arrow = one_year_later()
        date = datetime.utcnow() + timedelta(days=365)
        self.assertEqual(date.year, arrow.year)
        self.assertEqual(date.month, arrow.month)
        self.assertEqual(date.day, arrow.day)

    def test_switch_language(self):
        self.assertEqual("/?language=E", switch_language("http://localhost:5000/", "E"))
        self.assertEqual("/?language=E", switch_language("/", "E"))
        self.assertEqual("/?language=C", switch_language("http://filingHK.com/", "C"))
        self.assertEqual("/?language=C", switch_language("/", "C"))
        self.assertEqual("/latest?language=E", switch_language("http://localhost:5000/latest?language=C", "E"))
        self.assertEqual("/latest?language=E", switch_language("/latest?language=C", "E"))
        self.assertEqual("/latest?language=C", switch_language("http://filingHK.com/latest?language=C", "C"))
        self.assertEqual("/latest?language=C", switch_language("/latest?language=C", "C"))
        self.assertEqual("/login_form?email=j%40gmail.com&language=E", switch_language("http://localhost:5000/login_form?language=C&email=j%40gmail.com", "E"))
        self.assertEqual("/login_form?email=j%40gmail.com&language=E", switch_language("/login_form?language=C&email=j%40gmail.com", "E"))
