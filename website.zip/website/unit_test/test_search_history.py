from collections import deque
import unittest
from testsetup import TestCaseBasic
import app.constants as C
from app.searchhistory import SearchHistory


class testSearchHistory(TestCaseBasic):

    test_cookie_string = "[1\054 2\054 3\054 4]"

    def test_empty_deque_is_false(self):
        self.assertFalse(deque([]))

    def test_search_history_constructor(self):
        history = SearchHistory()
        self.assertTrue(history)
        self.assertFalse(history.stock_codes)

    def test_create_new_cookie_from_scratch(self):
        with self.app as context:
            # The empty string is the domain parameter.  See http://stackoverflow.com/a/33304946
            response = context.get('/')
            history = SearchHistory()
            self.assertEqual("[1]", history.create_new_cookie(1))

    def test_create_new_cookie_from_existing_history(self):
        with self.app as context:
            context.set_cookie("", C.SEARCH_HISTORY, self.test_cookie_string)
            response = context.get('/')
            history = SearchHistory()
            history.load_from_cookie()
            self.assertEqual("[1, 2, 3, 4, 5]", history.create_new_cookie(5))

    def test_history_with_cookie_is_true(self):
        with self.app as context:
            context.set_cookie("", C.SEARCH_HISTORY, self.test_cookie_string)
            response = context.get('/')
            history = SearchHistory()
            history.load_from_cookie()
            self.assertTrue(history.stock_codes)

    def test_history_with_empty_cookie_is_false(self):
        with self.app as context:
            context.set_cookie("", C.SEARCH_HISTORY, "")
            response = context.get('/')
            history = SearchHistory()
            history.load_from_cookie()
            self.assertFalse(history.stock_codes)

    def test_load_history_from_cookie(self):
        with self.app as context:
            # The empty string is the domain parameter.  See http://stackoverflow.com/a/33304946
            context.set_cookie("", C.SEARCH_HISTORY, self.test_cookie_string)
            response = context.get('/')
            history = SearchHistory()
            history.load_from_cookie()
            self.assertEqual(deque([1, 2, 3, 4]), history.stock_codes)

    def test_load_empty_history_from_cookie(self):
        history = SearchHistory()
        history.load_from_cookie()
        self.assertEqual(deque([]), history.stock_codes)

    def test_add_one_stock_code_to_history(self):
        history = SearchHistory()
        history.add_stock_code(1)
        self.assertEqual(deque([1]), history.stock_codes)

    def test_add_multiple_stock_codes_to_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4]:
            history.add_stock_code(stock_code)
        self.assertEqual(deque([1, 2, 3, 4]), history.stock_codes)

    def test_add_repeated_stock_codes_to_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 2]:
            history.add_stock_code(stock_code)
        self.assertEqual(deque([1, 3, 2]), history.stock_codes)

    def test_add_multiple_repeated_stock_codes_to_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 2, 2, 1, 1]:
            history.add_stock_code(stock_code)
        self.assertEqual(deque([2, 1]), history.stock_codes)

    def test_add_more_than_10_stock_codes_to_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
            history.add_stock_code(stock_code)
        self.assertEqual(deque([3, 4, 5, 6, 7, 8, 9, 10, 11, 12]), history.stock_codes)

    def test_add_more_than_10_repeated_stock_codes_to_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 4, 5, 13]:
            history.add_stock_code(stock_code)
        self.assertEqual(deque([6, 7, 8, 9, 10, 11, 12, 4, 5, 13]), history.stock_codes)

    def test_jsonify_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4]:
            history.add_stock_code(stock_code)
        self.assertEqual("[1, 2, 3, 4]", history.serialize())

    def test_jsonify_empty_history(self):
        history = SearchHistory()
        self.assertEqual("[]", history.serialize())

    def test_serialize_history(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4]:
            history.add_stock_code(stock_code)
        self.assertEqual("[1, 2, 3, 4]", history.serialize())

    def test_serialize_empty_history(self):
        history = SearchHistory()
        self.assertEqual("[]", history.serialize())

    def test_get_stock_codes_for_mysql(self):
        history = SearchHistory()
        for stock_code in [1, 2, 3, 4, 5]:
            history.add_stock_code(stock_code)
        self.assertEqual("1, 2, 3, 4, 5", history.get_stock_codes_for_mysql())

    def test_get_empty_stock_codes_for_mysql(self):
        history = SearchHistory()
        self.assertEqual("", history.get_stock_codes_for_mysql())
