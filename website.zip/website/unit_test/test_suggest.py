# coding=utf8
import json
from testsetup import TestCaseBasic

class SuggestTestCase(TestCaseBasic):

    def test_suggest_status_code(self):
        response = self.app.get("/suggest?phrase=1&language=E")
        self.assertEqual(200, response.status_code)

    def test_suggestion_count(self):
        response = self.app.get("/suggest?phrase=1")
        suggestions = json.loads(response.get_data())
        assert len(suggestions) == 6

    def test_suggestion_stock_code(self):
        response = self.app.get("/suggest?phrase=2")
        suggestions = json.loads(response.get_data())
        assert [s for s in suggestions if s["label"] == "CLP HOLDINGS"]

    def test_suggestion_zero_padded_stock_code(self):
        response = self.app.get("/suggest?phrase=00004")
        assert "WHARF HOLDINGS" in response.get_data()

    def test_suggestion_space_padded_stock_code(self):
        response = self.app.get("/suggest?phrase=    01398   ")
        suggestions = json.loads(response.get_data())
        assert "ICBC" in response.get_data()

    def test_suggestion_keyword(self):
        response = self.app.get("/suggest?phrase=hsbc")
        suggestions = json.loads(response.get_data())
        self.assertTrue([s for s in suggestions if s["value"] == 5])

    def test_cannot_find_suggestions(self):
        response = self.app.get("/suggest?phrase=this company doesn't exist")
        self.assertEqual("[]", response.data)

    def test_suggestion_status_code_empty_request(self):
        response = self.app.get("/suggest?phrase=")
        self.assertEqual(204,response.status_code)
