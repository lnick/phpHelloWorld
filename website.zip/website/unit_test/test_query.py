# coding=utf8
import unittest
from flask import g
from flask.ext.login import logout_user, login_user
import app.constants as C
from app.models import User, Watch
from testsetup import TestCaseBasic
from app.database.query import get_stock_name, get_suggestions, guess_stock_code, \
    get_watchlist_row_generator_logged_in, get_watchlist_row_generator_not_logged_in, \
    max_or_min, language
import app.exception as e
class TestQuery(TestCaseBasic):

    non_existing_stock_codes = [13, 49, 74, 134, 140, 150, 192, 349]

    search_dict = {
        # TODO:  add Chinese search phrases and expand the list
        "ckh"           : 1,
        "clp"           : 2,
        "2"             : 2,
        "5"             : 5,
        "hsbc"          : 5,
        "pccw"          : 8,
        "motor bus"     : 26,
        "-"             : 32,
        "("             : 30,
        ")"             : 30,
        "."             : 43,
        "ferry"         : 50,
        "Dan Form"      : 271,
        "vitasoy"       : 345,
        "ccb"           : 939,
        "ICBC"          : 1398,
        "greatwall"     : 2333,
        "zijin"         : 2899,
        "#"             : 60005,
        "@"             : 10304,
        "０"             : 1115,      # full-form number
        "中電"           : 2,
        "匯豐"           : 5
    }

    search_phrases_with_no_expected_results = [
        "no-existent company", "9999", "some typo", "  0 00 ",
        ";", "!", "$", "^", "\\", "/", ":", ";", "<",
        ">", "?", "`", "~", "|", "[", "]", "{", "}",
    ]

    search_phrases_that_expects_to_return_stock_code_1 = [
        "", "0", "ckh", "長和", "1", "0001", "00001", "%", "\"", "\"\"", "   ", "  00"
    ]

    def test_get_stock_name_english(self):
        g.language = C.ENGLISH
        self.assertEqual("CKH HOLDINGS", get_stock_name(1))
        self.assertEqual("CHINA MOTOR BUS", get_stock_name(26))

    def test_get_stock_name_chinese(self):
        g.language = C.CHINESE
        self.assertEqual("長和", get_stock_name(1))
        self.assertEqual("中華汽車", get_stock_name(26))

    def test_get_stock_name_from_invalid_stock_code(self):
        for language in [C.ENGLISH, C.CHINESE]:
            g.language = language
            self.assertRaises(e.NoStockNameFoundError, get_stock_name, "invalid stock code")

    def test_get_suggestions_english(self):
        g.language = C.ENGLISH
        expected_suggestions = [{'value':  5, 'label':'HSBC HOLDINGS'},
                                {'value':820, 'label':'HSBCDRAGON FUND'}]
        self.assertEqual(expected_suggestions, get_suggestions("hsbc"))
        self.assertEqual(expected_suggestions, get_suggestions("匯豐"))

    def test_get_suggestions_chinese(self):
        g.language = C.CHINESE
        expected_suggestions = [{'value':6823, 'label':'香港電訊-SS'}]
        self.assertEqual(expected_suggestions, get_suggestions("香港電訊"))
        self.assertEqual(expected_suggestions, get_suggestions("HKT-SS"))
        self.assertEqual(expected_suggestions, get_suggestions("6823"))

    def test_no_suggestions_found(self):
        for language in [C.ENGLISH, C.CHINESE]:
            g.language = language
            self.assertFalse(get_suggestions("some non-existent company"))
            self.assertFalse(get_suggestions("不存在的公司"))

    def test_get_suggestions_empty_string(self):
        g.language = C.ENGLISH
        expected_suggestion = {'value':1, 'label':'CKH HOLDINGS'}
        self.assertIn(expected_suggestion, get_suggestions(""))

    def test_get_suggestions_double_quotation_mark(self):
        g.language = C.ENGLISH
        expected_suggestion = {'value':1, 'label':'CKH HOLDINGS'}
        self.assertIn(expected_suggestion, get_suggestions("\""))

    @unittest.skip("slow")
    def test_guess_stock_code(self):
        for phrase in self.search_dict:
            self.assertEqual(self.search_dict[phrase], guess_stock_code(phrase))

    @unittest.skip("slow")
    def test_return_same_stock_code_if_existing_stock_code_is_entered(self):
        for stock_code in range(1, 200):  # TODO:  test all stock codes
            if stock_code not in self.non_existing_stock_codes:
                guess = guess_stock_code(str(stock_code))
                self.assertEqual(stock_code, guess)

    @unittest.skip("slow")
    def test_guess_stock_code_expects_stock_code_1(self):
        for phrase in self.search_phrases_that_expects_to_return_stock_code_1:
            self.assertEqual(1, guess_stock_code(phrase))

    @unittest.skip("slow")
    def test_guess_stock_code_expects_no_results_found(self):
        for phrase in self.search_phrases_with_no_expected_results:
            self.assertRaises(e.NoStockCodeFoundError, guess_stock_code, phrase)

    def test_guess_stock_code_empty_string(self):
        self.assertEqual(1, guess_stock_code(""))

    def test_watchlist_row_generator_while_logged_in(self):
        user = User.get_user_by_id(1)
        login_user(user)
        self.assertTrue(get_watchlist_row_generator_logged_in())

    def get_watchlist_row_generator_not_logged_in(self):
        logout_user()
        self.assertTrue(get_watchlist_row_generator_not_logged_in())

    def test_max_or_min(self):
        g.language = C.ENGLISH
        self.assertEqual("min", max_or_min())
        g.language = C.CHINESE
        self.assertEqual("max", max_or_min())

    def test_language(self):
        g.language = C.ENGLISH
        self.assertEqual("english", language())
        g.language = C.CHINESE
        self.assertEqual("chinese", language())
