# coding=utf8
from testsetup import TestCaseBasic

class TestCaseRoute(TestCaseBasic):

    def test_error_page_status_code(self):
        response = self.app.get('/some_non_existing_page')
        self.assertEqual(404, response.status_code)

    def test_error_page_content(self):
        response = self.app.get('/some_non_existing_page')
        self.assertIn("page not found", response.get_data())

    def test_error_page_content_chinese(self):
        response = self.app.get('/some_non_existing_page?language=C')
        self.assertIn("找不到網頁", response.get_data())
