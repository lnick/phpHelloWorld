# coding=utf8
import unittest
from flask import g
from testsetup import TestCaseBasic
from app.stream import create_error_response
from app.language import _

class TestReturnResponse(TestCaseBasic):

    def test_create_error_response(self):
        g.language = "E"
        response = create_error_response("Some error message")
        self.assertIn("Some error message", response)
        self.assertIn("alert-warning", response)

    def test_create_error_response_chinese(self):
        g.language = "C"
        response = create_error_response(_("Password cannot be empty"))
        self.assertIn("密碼不能空白", response)
