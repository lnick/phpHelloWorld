import unittest
import re
import json
from mysql.connector import ProgrammingError
from bs4 import BeautifulSoup
from flask import g, render_template, request, url_for
from flask.ext.login import current_user
from testsetup import TestCaseBasic
import app.exception as e
from app.models import User
from app.watchlist.views import render_watchlist_table_html
from app.utilscripts.usertables import create_user_data_tables

class TestWatchlistViews(TestCaseBasic):

    def test_watchlist_template_exists(self):
        self.assertTrue(render_template("watchlist.html"))

    def test_watchlist_status_code(self):
        response = self.app.get("/show_watchlist?language=E")
        self.assertEqual(200, response.status_code)

    def test_watchlist_has_no_table_html_if_no_search_history(self):
        response = self.app.get("/watchlist?language=E")
        self.assertNotIn("<table", response.data)
        self.assertFalse(re.findall("<tr.*>", response.data))

    def test_add_to_watchlist_status_code(self):
        response = self.app.get("/add_to_watchlist?phrase=1&language=E")
        self.assertEqual(200, response.status_code)

    @unittest.skip("slow")
    def test_add_to_watchlist_new_stock_code_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_add_watchlist_response_in_dict("hkex")
        self.assertEqual(388, response["stock_code"])
        self.assertEqual("HKEX", response["stock_name"])
        self.assertIsNone(response.get("exception"))

    @unittest.skip("slow")
    def test_add_to_watchlist_new_stock_name_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_add_watchlist_response_in_dict("hsbc")
        self.assertEqual(5, response["stock_code"])
        self.assertEqual("HSBC HOLDINGS", response["stock_name"])
        self.assertIsNone(response.get("exception"))

    def test_add_to_watchlist_existing_stock_code_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_add_watchlist_response_in_dict(271)
        self.assertEqual(e.StockCodeAlreadyOnWatchlistError.__name__, response.get("exception"))
        self.assertEqual(271, response["stock_code"])
        self.assertEqual("DAN FORM HOLD", response["stock_name"])

    def test_add_to_watchlist_invalid_stock_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_add_watchlist_response_in_dict("Some Non-Existing Company")
        self.assertEqual(e.NoStockCodeFoundError.__name__, response["exception"])
        self.assertIsNone(response.get("stock_code"))
        self.assertIsNone(response.get("stock_name"))

    @unittest.skip("slow")
    def test_add_to_watchlist_empty_string_while_logged_in(self):
        # Expects to add stock code 1
        self.login_sample_user(self.app)
        response = self.get_add_watchlist_response_in_dict("")
        self.assertEqual(1, response["stock_code"])
        self.assertEqual("CKH HOLDINGS", response["stock_name"])

    def test_add_to_watchlist_valid_stock_name_while_not_logged_in(self):
        response = self.get_add_watchlist_response_in_dict("hkex")
        self.assertIsNone(response.get("stock_code"))
        self.assertEqual(e.NotYetLoggedInError.__name__, response["exception"])
        self.assertIsNone(response.get("stock_name"))

    def test_add_to_watchlist_valid_stock_code_while_not_logged_in(self):
        response = self.get_add_watchlist_response_in_dict(293)
        self.assertEqual(e.NotYetLoggedInError.__name__, response["exception"])
        self.assertIsNone(response.get("stock_code"))
        self.assertIsNone(response.get("stock_name"))

    def test_add_to_watchlist_existing_stock_code_while_not_logged_in(self):
        response = self.get_add_watchlist_response_in_dict(6)
        self.assertEqual(e.NotYetLoggedInError.__name__, response.get("exception"))
        self.assertIsNone(response.get("stock_code"))
        self.assertIsNone(response.get("stock_name"))

    def test_add_to_watchlist_invalid_stock_while_not_logged_in(self):
        response1 = self.get_add_watchlist_response_in_dict("some non-existent company")
        response2 = self.get_add_watchlist_response_in_dict("")
        self.assertEqual(e.NoStockCodeFoundError.__name__, response1["exception"])
        self.assertEqual(e.NotYetLoggedInError.__name__, response2["exception"])
        self.assertIsNone(response1.get("stock_code"))
        self.assertIsNone(response2.get("stock_code"))
        self.assertIsNone(response1.get("stock_name"))
        self.assertIsNone(response2.get("stock_name"))

    def test_remove_from_watchlist_status_code(self):
        response = self.app.get("/remove_from_watchlist?stock_code=1&language=E")
        self.assertEqual(200, response.status_code)

    def test_remove_from_watchlist_existing_stock_code_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_remove_from_watchlist_response_in_dict(26)
        self.assertEqual(26, int(response["stock_code"]))
        self.assertEqual("CHINA MOTOR BUS", response["stock_name"])

    def test_remove_from_watchlist_stock_code_not_on_watchlist_while_logged_in(self):
        self.login_sample_user(self.app)
        response = self.get_remove_from_watchlist_response_in_dict(8)
        self.assertEqual(e.StockCodeNotOnWatchlistError.__name__, response.get("exception"))
        self.assertEqual(8, int(response["stock_code"]))
        self.assertEqual("PCCW", response["stock_name"])

    def test_remove_from_watchlist_invalid_stock_code_while_logged_in(self):
        self.login_sample_user(self.app)
        self.assertRaises(e.NoStockNameFoundError, self.get_remove_from_watchlist_response_in_dict, "invalid stock code")
        self.assertRaises(e.NoStockNameFoundError, self.get_remove_from_watchlist_response_in_dict, 9999)

    def test_remove_from_watchlist_while_logged_out(self):
        response = self.get_remove_from_watchlist_response_in_dict(6)
        self.assertEqual(e.NotYetLoggedInError.__name__, response.get("exception"))

    def test_remove_from_watchlist_invalid_stock_code_while_logged_out(self):
        self.assertRaises(e.NoStockNameFoundError, self.get_remove_from_watchlist_response_in_dict, "invalid stock code")
        self.assertRaises(e.NoStockNameFoundError, self.get_remove_from_watchlist_response_in_dict, "")
        self.assertRaises(e.NoStockNameFoundError, self.get_remove_from_watchlist_response_in_dict, 9999)

    def test_toggle_watchlist_while_logged_out(self):
        response = self.get_toggle_watchlist_response_in_dict("1")
        self.assertIn(e.NotYetLoggedInError.__name__, response["exception"])

    def test_toggle_watchlist_not_yet_on_watchlist(self):
        with self.app as context:
            self.login_sample_user(self.app)
            self.assertFalse(current_user.is_watching_stock_code(77))
            response = self.get_toggle_watchlist_response_in_dict("77")
            self.assertIn("ADDED", response["action"])

    def test_toggle_watchlist_already_on_watchlist(self):
        with self.app as context:
            self.login_sample_user(self.app)
            self.assertTrue(current_user.is_watching_stock_code(271))
            response = self.get_toggle_watchlist_response_in_dict("271")
            self.assertIn("REMOVED", response["action"])

    @unittest.skip("slow")
    def test_render_watchlist_table_html_while_logged_in(self):
        with self.app as context:
            self.login_sample_user(context)
            self.assertIn("table", render_watchlist_table_html())

    def test_login_sample_user_status_code(self):
        response = self.login_sample_user(self.app)
        self.assertEqual(204, response.status_code)

    def get_add_watchlist_response_in_dict(self, phrase):
        url = "/add_to_watchlist?phrase={0}&language=E".format(phrase)
        response = self.app.get(url)
        json_dict = json.loads(response.get_data())
        return json_dict

    def get_remove_from_watchlist_response_in_dict(self, stock_code):
        url = "/remove_from_watchlist?stock_code={0}&language=E".format(stock_code)
        response = self.app.get(url)
        json_dict = json.loads(response.get_data())
        return json_dict

    def get_toggle_watchlist_response_in_dict(self, stock_code):
        url = "/toggle_watchlist?stock_code={0}".format(stock_code)
        response = self.app.get(url)
        json_dict = json.loads(response.get_data())
        return json_dict

    def login_sample_user(self, context):
        credentials = dict(email="m@gmail.com", password="whisky2")
        response = context.post('/login', data=credentials)
        return response
