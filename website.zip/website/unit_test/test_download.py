# coding=utf8
import json
from testsetup import TestCaseBasic
from app.main.views import download_zip_file

class SuggestTestCase(TestCaseBasic):

    single_filename = {"filenames":"[LTN20150925499.pdf]"}

    def test_download_status_code_get_method_not_allowed(self):
        response = self.app.get("/download_zip_file", data=self.single_filename)
        self.assertEqual(405, response.status_code)

    def test_download_status_code_post_method(self):
        response = self.app.post("/download_zip_file", data=self.single_filename)
        self.assertEqual(200, response.status_code)
