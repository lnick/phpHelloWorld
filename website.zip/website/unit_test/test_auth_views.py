import unittest
from flask import g, url_for, render_template
from flask.ext.login import current_user
from testsetup import TestCaseBasic
from app.models import User
import app.constants as C
from app.auth.views import send_password_recovery_email

class TestLoginAndLogout(TestCaseBasic):

    good_email = "m@gmail.com"
    good_password= "whisky2"

    def test_is_not_authenticated_state_as_anonymous_user(self):
        with self.app as context:
            context.get("/")
            self.assertFalse(current_user.is_authenticated)

    def test_is_authenticated_state_after_successful_login(self):
        # See http://flask.pocoo.org/docs/0.10/testing/#faking-resources-and-context
        credentials = dict(email=self.good_email, password=self.good_password)
        with self.app as context:
            context.post("/login", data=credentials)
            self.assertTrue(current_user.is_authenticated)

    def test_is_not_authenticated_state_after_failed_login(self):
        credentials = dict(email=self.good_email, password="bad_password")
        with self.app as context:
            context.post("/login", data=credentials)
            self.assertFalse(current_user.is_authenticated)

    def test_is_not_authenticated_state_after_logout(self):
        credentials = dict(email=self.good_email, password=self.good_password)
        with self.app as context:
            context.post("/login", data=credentials)
            context.get("/logout")
            self.assertFalse(current_user.is_authenticated)

    def test_successful_login_status_code(self):
        credentials = dict(email=self.good_email, password=self.good_password)
        response = self.app.post("/login", data=credentials)
        self.assertEqual(204, response.status_code)

    def test_failed_login_bad_email(self):
        credentials = dict(email="bad_email@gmail.com", password=self.good_password)
        response = self.app.post("/login", data=credentials)
        self.assertIn("NoSuchUserError", response.data)
        self.assertEqual(200, response.status_code)

    def test_failed_login_no_email(self):
        credentials = dict(email="", password=self.good_password)
        response = self.app.post("/login", data=credentials)
        self.assertIn("NoSuchUserError", response.data)
        self.assertEqual(200, response.status_code)

    def test_failed_login_bad_password(self):
        credentials = dict(email=self.good_email, password="bad_password")
        response = self.app.post("/login", data=credentials)
        self.assertIn("BadPasswordError", response.data)
        self.assertEqual(200, response.status_code)

    def test_failed_login_no_password(self):
        credentials = dict(email=self.good_email, password="")
        response = self.app.post("/login", data=credentials)
        self.assertIn("BadPasswordError", response.data)
        self.assertEqual(200, response.status_code)

    def test_failed_login_no_email_and_password(self):
        credentials = dict(email="", password="")
        response = self.app.post("/login", data=credentials)
        self.assertIn("NoSuchUserError", response.data)
        self.assertEqual(200, response.status_code)

    def test_successful_logout_status_code_after_login(self):
        credentials = dict(email=self.good_email, password=self.good_password)
        self.app.post("/login", data=credentials)
        response = self.app.get("/logout")
        self.assertEqual(204, response.status_code)

    def test_successful_logout_status_code_without_logging_in(self):
        response = self.app.get("/logout")
        self.assertEqual(204, response.status_code)

    def test_login_does_not_allow_get_method(self):
        response = self.app.get("/login")
        self.assertEqual(405, response.status_code)

    def test_logout_does_not_allow_post_method(self):
        response = self.app.post("/logout")
        self.assertEqual(405, response.status_code)

    def test_create_account_success_login_required(self):
        response = self.app.get("/create_account_success")
        self.assertEqual(302, response.status_code)
        self.assertIn("/login_form", response.data)


class TestPasswordRecovery(TestCaseBasic):

    def test_password_recovery_page_exists(self):
        response = self.app.get(url_for("auth.recover_password"))
        self.assertEqual(200, response.status_code)

    @unittest.skip("slow")
    def test_recover_password_existing_user(self):
        response = self.app.get(url_for("auth.send_password", email="j@gmail.com", language=C.ENGLISH))
        self.assertFalse(response.data)

    @unittest.skip("slow")
    def test_send_password_recovery_email(self):
        g.language = C.ENGLISH
        user = User.get_user_by_email("brianlwh@gmail.com")
        response = send_password_recovery_email(user)
        self.assertEqual("Queued. Thank you.", response.json()["message"])
        self.assertEqual(200, response.status_code)

    def test_recover_password_non_existing_user(self):
        response = self.app.get(url_for("auth.send_password", email="non_existing_user@gmail.com", language=C.ENGLISH))
        self.assertIn("NoSuchUserError", response.data)


class TestSignUp(TestCaseBasic):

    user_data = {"email":"a@gmail.com", "password":"pw1", "password-retype":"pw1"}

    def test_sign_up_template_exists(self):
        self.assertTrue("/sign_up_form")

    def test_sign_up_form_status_code(self):
        response = self.app.get("/sign_up_form")
        self.assertEqual(200, response.status_code)

    def test_allow_create_account_by_post_method(self):
        response = self.app.post("/create_account", data=self.user_data)
        self.assertEqual(302, response.status_code)

    def test_alow_create_account_by_get_method(self):
        response = self.app.get("/create_account")
        self.assertEqual(200, response.status_code)
        self.assertIn("Email cannot be empty", response.data)

    def test_log_in_after_successful_sign_up(self):
        with self.app as context:
            user_data = {"email":"a_new_user@gmail.com", "password":"pw"}
            context.post("/create_account", data=user_data)
            self.assertEqual("a_new_user@gmail.com", current_user.email)

    def test_create_account_invalid_email_valid_password(self):
        user_data = {"email":"bad@bad_email", "password":"good_password"}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("doesn't look like a valid email", response.data)

    def test_create_account_invalid_email_no_password(self):
        user_data = {"email":"bad@bad_email", "password":""}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("doesn't look like a valid email", response.data)

    def test_create_account_no_email_valid_password(self):
        user_data = {"email":"", "password":"pw"}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("Email cannot be empty", response.data)

    def test_create_account_valid_email_no_password(self):
        user_data = {"email":"good_email@good.com", "password":""}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("Password cannot be empty", response.data)

    def test_create_account_already_registered_valid_password(self):
        user_data = {"email":"j@gmail.com", "password":"pw"}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("already registered", response.data)

    def test_create_account_already_registered_no_password(self):
        user_data = {"email":"j@gmail.com", "password":""}
        response = self.app.post("/create_account", data=user_data)
        self.assertIn("already registered", response.data)

    def test_create_account_no_data_redirect_to_sign_up_form(self):
        response = self.app.post("/create_account")
        self.assertIn("/sign_up_form", response.data)


class TestValidateEmail(TestCaseBasic):

    def test_validate_email_good_email(self):
        response = self.app.get(url_for("auth.validate_email", input="some_good_email@gmail.com"))
        self.assertFalse(response.data)

    def test_validate_email_empty_email(self):
        response = self.app.get(url_for("auth.validate_email", input=""))
        self.assertIn("EmailEmptyError", response.data)

    def test_validate_email_invalid_email(self):
        response = self.app.get(url_for("auth.validate_email", input="malformed@@@@@@gmail.com"))
        self.assertIn("EmailSyntaxError", response.data)

    def test_validate_email_valid_but_taken_email(self):
        response = self.app.get(url_for("auth.validate_email", input="j@gmail.com"))
        self.assertIn("EmailAlreadyTakenError", response.data)


class TestSettings(TestCaseBasic):

    def test_settings_redirect_to_login_if_not_logged_in(self):
        response = self.app.get("/settings")
        self.assertEqual(302, response.status_code)

    def test_settings_page_is_available_to_logged_in_user(self):
        with self.app as context:
            credentials = dict(email="m@gmail.com", password="whisky2")
            context.post("/login", data=credentials)
            response = context.get("/settings")
            self.assertIn("Settings", response.data)
            self.assertEqual(200, response.status_code)

    def test_change_password_correctly(self):
        with self.app as context:
            credentials = dict(email="brianlwh@gmail.com", password="nokiaapple")
            context.post("/login", data=credentials)
            data = dict(old_password="nokiaapple", new_password="new_password")
            response = context.post("/change_password", data=data)
            self.assertFalse(response.data)
            self.assertEqual(204, response.status_code)

    def test_change_password_wrong_old_password(self):
        with self.app as context:
            credentials = dict(email="m@gmail.com", password="whisky2")
            context.post("/login", data=credentials)
            data = dict(old_password="wrong_old_password", new_password="new_password")
            response = context.post("/change_password", data=data)
            self.assertIn("BadPasswordError", response.data)

    def test_change_password_no_new_password_supplied(self):
        with self.app as context:
            credentials = dict(email="m@gmail.com", password="whisky2")
            context.post("/login", data=credentials)
            data = dict(old_password="whisky2", new_password="")
            response = context.post("/change_password", data=data)
            self.assertIn("InvalidPasswordError", response.data)
