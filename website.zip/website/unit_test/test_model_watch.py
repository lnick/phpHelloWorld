from app.models import User, Watch
from testsetup import TestCaseBasic

class TestWatch(TestCaseBasic):

    def test_watch_string_representation(self):
        watch = Watch.query.filter_by(watch_id=3).one()
        self.assertEqual("<Watch 3, user_id=2, stock_code=26>", str(watch))
