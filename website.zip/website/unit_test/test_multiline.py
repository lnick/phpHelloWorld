# coding=utf8
import unittest
import app.constants as C
from app.display.multiline import multiline

class TestMiltiline(unittest.TestCase):

    def test_numbered_bullets_in_parentheses(self):
        self.assertEqual(multiline(
            "Inside Information (1) Resumption of Trading (2) Voluntary Unconditional Cash Offers (3) Complaints From Shareholders and Directors Between 2 May 2014 and 22 May 2014 (4) Court Proceedings in BERMUDA (5) REQUISITIONISTS' SGM (6) Legality and Authority for MR. Law FONG and MR. Mike CHEN to Issue This Announcement (7) Disputed Board Composition and Objections by MR. JAMES OUNG and MR. KWOK WAI Chi to the Making of This Announcement (8) Appointment of Alternate Director", C.ENGLISH),
            "Inside Information<br> (1) Resumption of Trading<br> (2) Voluntary Unconditional Cash Offers<br> (3) Complaints From Shareholders and Directors Between 2 May 2014 and 22 May 2014<br> (4) Court Proceedings in BERMUDA<br> (5) REQUISITIONISTS' SGM<br> (6) Legality and Authority for MR. Law FONG and MR. Mike CHEN to Issue This Announcement<br> (7) Disputed Board Composition and Objections by MR. JAMES OUNG and MR. KWOK WAI Chi to the Making of This Announcement<br> (8) Appointment of Alternate Director")

    def test_no_newline(self):
        self.assertEqual(multiline(
            "Monthly Return of Equity Issuer on Movements in Securities and Share Buyback for the Month Ended 31st March, 2015", C.ENGLISH),
            "Monthly Return of Equity Issuer on Movements in Securities and Share Buyback for the Month Ended 31st March, 2015")

    def test_no_newline_for_short_sentence_in_english(self):
        self.assertEqual(multiline(
            "Exchange Notice - Resumption of Trading", C.ENGLISH),
            "Exchange Notice - Resumption of Trading")

    def test_no_newline_for_short_sentence_in_chinese(self):
        self.assertEqual(multiline(
            "交易所通告 - 復牌", C.CHINESE),
            "交易所通告 - 復牌")

    def test_newline_for_long_title_with_dash(self):
        self.assertEqual(multiline(
            "Notification Letter to Registered Holder - Notice of Publication of Circular, Notice of Meeting and Proxy Form", C.ENGLISH),
            "Notification Letter to Registered Holder - <br>Notice of Publication of Circular, Notice of Meeting and Proxy Form")

    def test_newline_after_colon_or_semicolon(self):
        self.assertEqual(multiline(
            "Joint Announcement - Merger & Spin-off Proposals: Husky Share Exchange Completion; HUTCHISON Scheme Effective Date, HUTCHISON Proposal Completion & CKHH Share Certificates Despatch; HUTCHISON Shares Listing Withdrawal; Property Businesses Combination, Distribution in Specie & Spin-off Proposal Completion & CKP Share Certificates Despatch; CKP Shares Dealings & Odd Lot Matching Service Commencement; CKHH'S Board, Company Secretary, Authorised Representatives & Principal Place of Business Changes", C.ENGLISH),
            "Joint Announcement - <br>Merger & Spin-off Proposals:<br> Husky Share Exchange Completion;<br> HUTCHISON Scheme Effective Date, HUTCHISON Proposal Completion & CKHH Share Certificates Despatch;<br> HUTCHISON Shares Listing Withdrawal;<br> Property Businesses Combination, Distribution in Specie & Spin-off Proposal Completion & CKP Share Certificates Despatch;<br> CKP Shares Dealings & Odd Lot Matching Service Commencement;<br> CKHH'S Board, Company Secretary, Authorised Representatives & Principal Place of Business Changes")

    def test_no_newline_after_hyphen(self):
        self.assertEqual(multiline(
            "Merger & Spin-off Proposals, Husky Share Exchange Completion, HUTCHISON Scheme Effective Date and HUTCHISON Proposal Completion", C.ENGLISH),
            "Merger & Spin-off Proposals, Husky Share Exchange Completion, HUTCHISON Scheme Effective Date and HUTCHISON Proposal Completion")

    def test_no_double_newline(self):
        self.assertEqual(multiline(
            "...by Way of A Scheme of Arrangement (1) Result of Hearing of the Petition to Sanction the Scheme; (2) Expected Timetable of Cert...", C.ENGLISH),
            "...by Way of A Scheme of Arrangement<br> (1) Result of Hearing of the Petition to Sanction the Scheme;<br> (2) Expected Timetable of Cert...")

    def test_no_newline_at_beginning(self):
        self.assertEqual(multiline(
            "(1) Merger Proposal - (a) Proposed Share Exchange Offer to the Scheme Shareholders for the Cancellation of All the Scheme Shares by Way...", C.ENGLISH),
            "(1) Merger Proposal - <br>(a) Proposed Share Exchange Offer to the Scheme Shareholders for the Cancellation of All the Scheme Shares by Way...")

    def test_no_newline_for_bracketed_bullets_not_preceded_by_space(self):
        self.assertEqual(multiline(
            "Application for Waiver Under Rule 14.41(A) of the Listing Rules and Further Delay in Despatch of Circular", C.ENGLISH),
            "Application for Waiver Under Rule 14.41(A) of the Listing Rules and Further Delay in Despatch of Circular")

    def test_lowercase_roman_numberal_bullets_in_parentheses(self):
        self.assertEqual(multiline(
            "(i) REDESIGNATION of A Director (ii) Appointment of an Independent Non-executive Director<br> (iii) List of Directors and Their Roles and Functions", C.ENGLISH),
            "(i) REDESIGNATION of A Director<br> (ii) Appointment of an Independent Non-executive Director<br> (iii) List of Directors and Their Roles and Functions")

    def test_uppercase_roman_numberal_bullets_in_parentheses(self):
        self.assertEqual(multiline(
            "(I) Proposed Expansion of the Asset Class of The Link REIT's Investment Strategy, (II) Proposed Grant of Power for The Link REIT to make Charitable Donations and Sponsorships, (III) Proposed Ancillary Amendments to the Trust Deed, and (IV) Notice of Annual General Meeting", C.ENGLISH),
            "(I) Proposed Expansion of the Asset Class of The Link REIT's Investment Strategy,<br> (II) Proposed Grant of Power for The Link REIT to make Charitable Donations and Sponsorships,<br> (III) Proposed Ancillary Amendments to the Trust Deed, and<br> (IV) Notice of Annual General Meeting")

    def test_no_newline_for_alphabet_in_parentheses_not_preceded_by_whitespace(self):
        self.assertEqual(multiline(
            "Form of Acceptance and Transfer of Ordinary Share(s) of HK$0.01 Each in the Issued Share Capital of Paladin Limited", C.ENGLISH),
            "Form of Acceptance and Transfer of Ordinary Share(s) of HK$0.01 Each in the Issued Share Capital of Paladin Limited")

    def test_newline_before_and_after_long_text_in_parantheses(self):
        self.assertEqual(multiline(
            "Voluntary Unconditional Cash Offers by ANGLO CHINESE Corporate Finance, Limited on Behalf of Gold Seal Holdings Limited to Acquire All the Issued Shares in Paladin Limited (other Than Those Already Owned and, or Agreed to be Acquired by Gold Seal Holdings Limited and, or Parties Acting in Concert with It) Results of the Offers on 8 September, 2014 Further Extension of the Offers", C.ENGLISH),
            "Voluntary Unconditional Cash Offers by ANGLO CHINESE Corporate Finance, Limited on Behalf of Gold Seal Holdings Limited to Acquire All the Issued Shares in Paladin Limited <br>(other Than Those Already Owned and, or Agreed to be Acquired by Gold Seal Holdings Limited and, or Parties Acting in Concert with It)<br> Results of the Offers on 8 September, 2014 Further Extension of the Offers")

    def test_no_newline_between_and_semicolon(self):
        self.assertEqual(multiline(
            "(1) Result of Hearing of the Petition to Sanction the Scheme; (2) Expected Timetable of Certain Events; and (3) Resumption of Dealings in the Debt Securities", C.ENGLISH),
            "(1) Result of Hearing of the Petition to Sanction the Scheme;<br> (2) Expected Timetable of Certain Events; and<br> (3) Resumption of Dealings in the Debt Securities")

    def test_chinese_semicolon(self):
        self.assertEqual(multiline(
            u"公佈撤銷一名董事職務；委任董事；審核委員會、提名委員會及薪酬委員會成員之變動；及更換公司秘書", C.CHINESE),
            u"公佈撤銷一名董事職務；<br>委任董事；<br>審核委員會、提名委員會及薪酬委員會成員之變動；及<br>更換公司秘書")

    def test_newline_after_slash(self):
        self.assertEqual(multiline(
            "Purchase of 12.5% Shareholding in Cathay Pacific Airways Limited / Price Sensitive Information / Disposal of 14.5% Shareholding in Cathay Pacific Airways Limited / Purchase of 2% Shareholding in Cathay Pacific Airways Limited / Resumption of Trading", C.ENGLISH),
            "Purchase of 12.5% Shareholding in Cathay Pacific Airways Limited / <br>Price Sensitive Information / <br>Disposal of 14.5% Shareholding in Cathay Pacific Airways Limited / <br>Purchase of 2% Shareholding in Cathay Pacific Airways Limited / <br>Resumption of Trading")
