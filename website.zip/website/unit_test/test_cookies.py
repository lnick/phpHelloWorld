import unittest
import Cookie
from flask import url_for
from testsetup import TestCaseBasic
import app.constants as C


class TestCookies(TestCaseBasic):

    def test_search_status_code(self):
        response = self.app.get("/search?phrase=1&language=E")
        self.assertEqual(200, response.status_code)

    def test_homepage_language_cookies(self):
        with self.app as context:
            response = self.app.get("/")
            self.assertEqual("E", self.get_cookie(C.LANGUAGE, response))
            response = self.app.get("/?language=E")
            self.assertEqual("E", self.get_cookie(C.LANGUAGE, response))
            response = self.app.get("/?language=C")
            self.assertEqual("C", self.get_cookie(C.LANGUAGE, response))

    def test_search_language_cookies(self):
        with self.app as context:
            response = context.get("/search?phrase=1&language=E")
            self.assertEqual("E", self.get_cookie(C.LANGUAGE, response))
            response = context.get("/search?phrase=1&language=C")
            self.assertEqual("C", self.get_cookie(C.LANGUAGE, response))

    def test_search_history_cookies_no_history(self):
        with self.app as context:
            response = context.get("/")
            self.assertRaises(KeyError, self.get_cookie, C.SEARCH_HISTORY, response)

    @unittest.skip("slow")
    def test_search_history_cookies_short_list(self):
        with self.app as context:
            response = context.get("/search?phrase=1&language=E")
            response = context.get("/search?phrase=2&language=C")
            response = context.get("/search?phrase=3&language=E")
            cookie = self.get_cookie(C.SEARCH_HISTORY, response)
            self.assertEqual("[1, 2, 3]", cookie)

    @unittest.skip("slow")
    def test_search_history_cookies_with_repetition(self):
        with self.app as context:
            response = context.get("/search?phrase=1&language=E")
            response = context.get("/search?phrase=2&language=C")
            response = context.get("/search?phrase=3&language=E")
            response = context.get("/search?phrase=4&language=E")
            response = context.get("/search?phrase=5&language=C")
            response = context.get("/search?phrase=6&language=E")
            response = context.get("/search?phrase=7&language=E")
            response = context.get("/search?phrase=8&language=C")
            response = context.get("/search?phrase=9&language=E")
            response = context.get("/search?phrase=10&language=E")
            response = context.get("/search?phrase=11&language=E")
            response = context.get("/search?phrase=12&language=C")
            cookie = self.get_cookie(C.SEARCH_HISTORY, response)
            self.assertEqual("[3, 4, 5, 6, 7, 8, 9, 10, 11, 12]", cookie)

    @unittest.skip("slow")
    def test_latest_language_cookies(self):
        with self.app as context:
            response = context.get("/latest?language=E")
            self.assertEqual("E", self.get_cookie(C.LANGUAGE, response))
            response = context.get("/latest?language=C")
            self.assertEqual("C", self.get_cookie(C.LANGUAGE, response))

    def test_watchlist_language_cookies(self):
        with self.app as context:
            response = context.get("/show_watchlist?language=E")
            self.assertEqual("E", self.get_cookie(C.LANGUAGE, response))
            response = context.get("/show_watchlist?language=C")
            self.assertEqual("C", self.get_cookie(C.LANGUAGE, response))

    def get_cookie(self, name, response):
        headers = response.headers.getlist("Set-Cookie")
        cookie = Cookie.SimpleCookie()
        for header in headers:
            cookie.load(header)
        return cookie[name].value
