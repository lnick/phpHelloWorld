import unittest
from app.display.titlecase import titlecase

class TestTitlecase(unittest.TestCase):

    def test_ignore_lowercase_titles(self):
        self.assertEqual(titlecase(
            "The Acquisition of CKH Holdings"),
            "The Acquisition of CKH Holdings")

    def test_capitalize_first_alphabet(self):
        self.assertEqual(titlecase(
            "THE DATE OF BOARD MEETING"),
            "The Date of Board Meeting")

    # Test English words

    def test_english_words(self):
        self.assertEqual(titlecase(
            "ANNUAL GENERAL MEETING"),
            "Annual General Meeting")

    def test_hyphenated_english_word(self):
        self.assertEqual(titlecase(
            "PURCHASE OF HKD INDEX-LINKED NOTE WITH KNOCK-OUT CALL"),
            "Purchase of HKD Index-linked Note with Knock-out Call")

    def test_hyphenated_non_english_word(self):
        self.assertEqual(titlecase(
            "ACQUISITION OF IDR-NOTES"),
            "Acquisition of IDR-NOTES")

    def test_nth_day_of_month_and_month_of_year(self):
        self.assertEqual(titlecase(
            "MEETING HELD ON 16TH NOVEMBER 2015 AND 1ST JULY 2016"),
            "Meeting Held on 16th November 2015 and 1st July 2016")

    def test_common_words(self):
        self.assertEqual(titlecase(
            "OFFER FOR ABC IS UNCONDITIONAL IF CERTAIN CONDITIONS ARE FULFILLED"),
            "Offer for ABC Is Unconditional if Certain Conditions Are Fulfilled")

    def test_starts_with_alphabets_of_common_word(self):
        self.assertEqual(titlecase(
            "ENFORCEMENT OF SECURITY"),
            "Enforcement of Security")

    def test_single_alphabet(self):
        self.assertEqual(titlecase(
            "POLL RESULTS OF (I) A SHARES MEETING (II) H SHARES MEETING"),
            "Poll Results of (i) A Shares Meeting (ii) H Shares Meeting")

    def test_us_dollar(self):
        self.assertEqual(titlecase(
            "ISSUE OF US$500,000,000 5.375% BOND"),
            "Issue of US$500,000,000 5.375% Bond")

    # Test punctuations

    def test_punctuation_isolated_hyphen(self):
        self.assertEqual(titlecase(
            "DISCLOSURE -  CHANGES IN ISSUED SHARE CAPITAL"),
            "Disclosure - Changes in Issued Share Capital")

    def test_punctuation_colon(self):
        self.assertEqual(titlecase(
            "UPDATE OF THE CONNECTED TRANSACTION: ACQUISITION OF CUIDAO HOTSPRING HOTEL"),
            "Update of the Connected Transaction: Acquisition of CUIDAO HOTSPRING Hotel")

    def test_punctuation_bracket(self):
        self.assertEqual(titlecase(
            "COMPLETION OF THE DISPOSAL OF BAPP (North) LIMITED"),
            "Completion of the Disposal of BAPP (north) Limited")

    def test_punctuation_semicolon(self):
        self.assertEqual(titlecase(
            "(1) PROPOSED GENERAL MANDATE; (2) PROPOSED REFRESHMENT OF SCHEME MANDATE"),
            "(1) Proposed General Mandate; (2) Proposed Refreshment of Scheme Mandate")

    def test_punctuation_comma(self):
        self.assertEqual(titlecase(
            "APPOINTMENT, RESIGNATION AND RE-DESIGNATION, OF DIRECTORS"),
            "Appointment, Resignation and Re-designation, of Directors")

    def test_punctuation_apostrophe(self):
        self.assertEqual(titlecase(
            "CONTROL AND MANAGEMENT OF CERTAIN OF THE GROUP'S HOTELS"),
            "Control and Management of Certain of the Group's Hotels")

    def test_punctuation_ends_with_bracket(self):
        self.assertEqual(titlecase(
            "UPDATE ON BUSINESS DEVELOPMENT("),
            "Update on Business Development(")

    def test_punctuation_ends_with_hyphen(self):
        self.assertEqual(titlecase(
            "UPDATE ON BUSINESS DEVELOPMENT-"),
            "Update on Business Development-")

    # Test numbers

    def test_decimals(self):
        self.assertEqual(titlecase(
            "ANNOUNCEMENT PURSUANT TO RULE 3.8 OF THE TAKEOVERS CODE"),
            "Announcement Pursuant to Rule 3.8 of the Takeovers Code")

    def test_decimal_with_alphabet(self):
        self.assertEqual(titlecase(
            "RULE 13.1A"),
            "Rule 13.1A")

    def test_numbers(self):
        self.assertEqual(titlecase(
            "HK$10,000,000 0.1 PER CENT BONDS DUE 2031"),
            "HK$10,000,000 0.1 Per Cent Bonds Due 2031")

    # Test bullet points

    def test_roman_numerals_bullets(self):
        self.assertEqual(titlecase(
            "(I) RE-ELECTION OF A DIRECTOR; AND (II) NOTICE OF SPECIAL GENERAL MEETING"),
            "(i) Re-election of A Director; and (ii) Notice of Special General Meeting")

    def test_more_roman_numerals_bullets(self):
        self.assertEqual(titlecase(
            "(I) ABC, (II) XYZ, (III) GHI, (IV) JKL & (V) MNO"),
            "(i) ABC, (ii) XYZ, (iii) GHI, (iv) JKL & (v) MNO")

    def test_numbered_bullets(self):
        self.assertEqual(titlecase(
            "MERGER PROPOSAL (1) RESULT OF THE COURT HEARING (2) EXPECTED TIMETABLE"),
            "Merger Proposal (1) Result of the Court Hearing (2) Expected Timetable")

    def test_alphabet_bullet_points(self):
        self.assertEqual(titlecase(
            "MERGER PROPOSAL - (A) PROPOSED ISSUE OF SHARES; AND (B) PROPOSED EXCHANGE OFFER"),
            "Merger Proposal - (a) Proposed Issue of Shares; and (b) Proposed Exchange Offer")

    # Corner cases
    def test_single_hyphen(self):
        self.assertEqual(titlecase("-"), "-")

    def test_empty_string(self):
        self.assertEqual(titlecase(""), "")

    def test_space_only_string(self):
        self.assertEqual(titlecase("  "), "")

    def test_one_alphabet(self):
        self.assertEqual(titlecase("a"), "A")
