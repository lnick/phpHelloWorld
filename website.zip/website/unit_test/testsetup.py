import unittest
from app import create_app
from app.utilscripts.usertables import create_user_data_tables
from config import DevelopmentConfig

class TestCaseBasic(unittest.TestCase):

    def setUp(self):
        self.app = create_app(DevelopmentConfig).test_client()
