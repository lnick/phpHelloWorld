class BaseConfig:
    MAILGUN_API_URL = "https://api.mailgun.net/v3/filinghk.com/messages"
    MAILGUN_API_KEY = "key-4935f091f949ebe30c438e575e72ba56"
    SECRET_KEY = "TUkkEp!k7PHHHU8&hbD!I!ld&f^xSQ#$y8egG&*c*t^x9@*sTx"
    SEND_FILE_MAX_AGE_DEFAULT = 7776000     # in seconds, i.e. 90 days
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    PRESERVE_CONTEXT_ON_EXCEPTION = False


class ProductionConfig(BaseConfig):
    SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://website:nokiaapple@172.18.1.129/hk"
    MYSQL_LOGIN_CREDENTIALS = {
        "host"      : "172.18.1.129",
        "user"      : "website",
        "password"  : "nokiaapple",
        "database"  : "hk"
    }


class DevelopmentConfig(BaseConfig):
    THREADED = True
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://website:nokiaapple@localhost/test_hk"
    MYSQL_LOGIN_CREDENTIALS = {
        "host"      : "localhost",
        "user"      : "website",
        "password"  : "nokiaapple",
        "database"  : "test_hk"
    }
