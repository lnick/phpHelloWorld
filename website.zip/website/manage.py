import sys
import os
import unittest
from flask.ext.script import Manager
from flask.ext.migrate import MigrateCommand
from app import create_app
from app.utilscripts.usertables import create_user_data_tables
from app.utilscripts.warmup import warm_up_mysql_server
from config import DevelopmentConfig, ProductionConfig


if os.environ["WEBSITE_ENVIRONMENT"] == "PRODUCTION":
    app = create_app(ProductionConfig)
elif os.environ["WEBSITE_ENVIRONMENT"] == "DEVELOPMENT":
    app = create_app(DevelopmentConfig)


manager = Manager(app)
manager.add_command("db", MigrateCommand)


@manager.command
def check_environment():
    """Check the environment variable WEBSITE_ENVIRONMENT.  Should be either 'DEVELOPMENT' or 'PRODUCTION'"""
    print "The current environment is", os.environ["WEBSITE_ENVIRONMENT"]


@manager.command
def test():
    """Run the unit tests"""
    create_user_data_tables()
    tests = unittest.TestLoader().discover("unit_test")
    unittest.TextTestRunner(verbosity=1).run(tests)
    create_user_data_tables()
    sys.exit()


@manager.command
def warm_up():
    """Warm up database"""
    warm_up_mysql_server()


if __name__ == "__main__":
    manager.run()
