from functools import wraps
from flask import g, redirect, url_for, render_template
from flask.ext.login import login_user, logout_user, LoginManager, current_user
from email_validator import EmailSyntaxError
from . import auth
from .. import exception as e
from ..util import get_request_data, jsonify_exception, send_email
from ..language import _
from ..models import User
from ..stream import render_template_stream, create_error_response

login_manager = LoginManager()

def login_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):
        if not current_user.is_authenticated:
            login_form_url = url_for("auth.login_form", language=g.language)
            return redirect(login_form_url)
        return f(*args, **kwargs)
    return decorator


@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))


@auth.route("/login_form")
def login_form():
    return render_template_stream("login.html")


@auth.route("/recover_password")
def recover_password():
    return render_template_stream("recover_password.html")


@auth.route("/send_password")
def send_password():
    try:
        email = get_request_data("email")
        user = User.get_user_by_email(email)
        send_password_recovery_email(user)
        return "", 204
    except (e.NoSuchUserError) as err:
        return jsonify_exception(err)


def send_password_recovery_email(user):
    to_address = user.email
    from_address = _("Password reminder") + " <support@filingHK.com>"
    subject = _("Your password at filingHK.com")
    body_html = render_template("password_recovery_email.html", user=user)
    return send_email(to_address, from_address, subject, body_html)


@auth.route("/login", methods=["POST"])
def login():
    try:
        logout_user()
        email = get_request_data("email")
        password = get_request_data("password")
        user = User.get_user_by_email(email)
        user.check_password(password)
        login_user(user, remember=True)
        return "", 204
    except (e.NoSuchUserError, e.BadPasswordError) as err:
        return jsonify_exception(err)


@auth.route("/logout")
def logout():
    logout_user()
    return "", 204


@auth.route("/sign_up_form")
def sign_up_form():
    return render_template_stream("sign_up_form.html")


@auth.route("/create_account", methods=["POST", "GET"])
def create_account():
    try:
        email, password = get_request_data("email"), get_request_data("password")
        User.validate_user_data(email, password)
        new_user = User(email=email, password=password)
        User.create_account(new_user)
        login_user(new_user, remember=True)
        url_success = url_for("auth.create_account_success", language=g.language)
        return redirect(url_success)
    except Exception as err:
        return handle_create_account_errors(err, email)


def handle_create_account_errors(err, email):
    if isinstance(err, e.EmailEmptyError):
        return create_error_response(_("Email cannot be empty"))
    if isinstance(err,  e.EmailAlreadyTakenError):
        return create_error_response(_("Email <em>{0}</em> is already registered").format(email))
    if isinstance(err,  EmailSyntaxError):
        return create_error_response(_("<em>{0}</em> doesn't look like a valid email").format(email))
    if isinstance(err,  e.InvalidPasswordError):
        return create_error_response(_("Password cannot be empty"))


@auth.route("/create_account_success")
@login_required
def create_account_success():
    return render_template_stream("create_account_success.html")


@auth.route("/validate_email")
def validate_email():
    try:
        email = get_request_data("input")
        User.validate_email(email)
        User.check_if_email_is_already_taken(email)
        return "", 204
    except (EmailSyntaxError, e.EmailAlreadyTakenError, e.EmailEmptyError) as err:
        return jsonify_exception(err)


@auth.route("/settings")
@login_required
def settings():
    return render_template_stream("settings.html")


@auth.route("/change_password", methods=["POST"])
@login_required
def change_password():
    try:
        old_password = get_request_data("old_password")
        new_password = get_request_data("new_password")
        current_user.check_password(old_password)
        User.validate_password(new_password)
        current_user.change_password(new_password)
        return "", 204
    except (e.BadPasswordError, e.InvalidPasswordError) as err:
        return jsonify_exception(err)
