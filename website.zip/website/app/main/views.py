import json
from flask import g, Response, request, redirect
from flask.ext.login import current_user
from . import main
from .. import exception as e
from ..stream import render_template_stream, create_error_response
from ..database.query import get_suggestions, get_stock_name, guess_stock_code, get_search_row_generator, get_latest_row_generator
from ..display.htmlrows import generate_html_rows
from ..util import get_request_data
from ..searchhistory import SearchHistory
from ..language import _
from download import create_stream_zip_file_response


@main.route("/")
def index():
    return render_template_stream("home.html")


@main.route('/latest')
def latest():
    row_generator = get_latest_row_generator()
    rows = generate_html_rows(row_generator)
    return render_template_stream("latest.html", rows=rows)


@main.route('/search')
def search():
    try:
        # Some users may have bookmarked link with "stock_code" as request argments
        stock_code = get_request_data("stock_code", default="")
        phrase = get_request_data("phrase", default=stock_code)
        stock_code = guess_stock_code(phrase)
        return stream_template_found_stock_code(stock_code)
    except e.NoStockCodeFoundError:
        return render_template_cannot_find_stock(phrase)


@SearchHistory.add_search_history_cookie
def stream_template_found_stock_code(stock_code):
    row_generator = get_search_row_generator(stock_code, get_first_30_rows=True)
    rows = generate_html_rows(row_generator)
    stock_name = get_stock_name(stock_code)
    return render_template_stream("search.html", rows=rows, stock_code=stock_code, stock_name=stock_name)


def render_template_cannot_find_stock(phrase):
    error_msg = _("Sorry, cannot find company <em>{}</em>").format(phrase)
    return create_error_response(error_msg=error_msg)


@main.route("/search_show_older")
def search_show_older():
    stock_code = get_request_data("stock_code")
    row_generator = get_search_row_generator(stock_code, get_first_30_rows=False)
    rows = generate_html_rows(row_generator)
    return render_template_stream("table_search.html", rows=rows)


@main.route("/suggest")
def suggest():
    phrase = get_request_data("phrase")
    if phrase:
        suggestions = get_suggestions(phrase)
        json_response = json.dumps(suggestions)
        return Response(json_response,  mimetype='application/json')
    else:
        return "", 204


# Must be POST method, because Apache2 server limits the length of GET argument string
@main.route("/download_zip_file", methods=["POST"])
def download_zip_file():
    return  create_stream_zip_file_response()


@main.route("/testing")
def testing():
    return redirect("http://filinghk-sandbox.cloudplatform.hk/")
