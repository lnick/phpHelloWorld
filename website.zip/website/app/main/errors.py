from flask import g, render_template, current_app
from . import main
from ..language import _
from ..stream import create_error_response


@main.app_errorhandler(404)
def page_not_found(e):
    return create_error_response(_("Sorry, page not found")), 404


@main.app_errorhandler(500)
def internal_server_error(e):
    return create_error_response(_("Sorry, something went wrong with our site.")), 500
