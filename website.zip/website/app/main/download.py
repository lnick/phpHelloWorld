# coding=utf8
import os
import re
from zipfile import ZIP_DEFLATED
from zipstream import ZipFile
import requests
from flask import g, json, stream_with_context, Response  # TODO:  replace json with Python's JSON library
from retrying import retry
from .. import constants as C
from ..util import get_request_data
from ..database.query import get_shortened_title
from ..display.titlecase import titlecase
from ..display.url import create_url_from_filename, get_year, get_month, get_day

HELP_NOTE_FILE_NAME = "_Help! Chinese filenames are garbled.txt"
HELP_NOTE_CONTENT = "為甚麼中文檔案名稱變成亂碼?\n=========================\nWindows預設的Zip檔解壓程式並不支援中文檔名。\n請使用WinRAR、7-Zip或WinZip。"


def create_stream_zip_file_response():
    zip_file_stream = stream_with_context(generate_zip_file_chunks())
    response = Response(zip_file_stream)
    response = set_zip_file_response_headers(response)
    return response


def set_zip_file_response_headers(response):
    response.headers["Content-Disposition"] = "attachment; filename=Filings.zip"
    response.mimetype = "application/x-zip-compressed"
    # The following cookies are required for fileDownload.js plug-in
    # See http://johnculviner.com/jquery-file-download-plugin-for-ajax-like-feature-rich-file-downloads/
    response.set_cookie("fileDownload", value="true")
    response.set_cookie("path", value="/")
    return response


def generate_zip_file_chunks():
    # Using "yield" so that zip file is streamed
    for chunk in create_zip_file():
        yield chunk


def create_zip_file():
    zip_file = ZipFile(mode='w', compression=ZIP_DEFLATED)
    add_help_note_on_chinese_filenames(zip_file)
    add_filings(zip_file)
    return zip_file


def add_help_note_on_chinese_filenames(zip_file):
    # Chinese filenames are not supported by the "Compressed (zipped) Folders" in Windows 7
    # This is a limitation of Windows.  See:  http://superuser.com/a/481366
    if g.language == C.CHINESE:
        zip_file.write_iter(HELP_NOTE_FILE_NAME, HELP_NOTE_CONTENT)


def add_filings(zip_file):
    for filename in parse_requested_filenames():
        download_rename_and_write_to_zip_file(filename, zip_file)


def download_rename_and_write_to_zip_file(old_name, zip_file):
    content = download_chunks_from_hkex(old_name)
    new_name = create_and_clean_up_new_filename(old_name)
    zip_file.write_iter(new_name, content)


def parse_requested_filenames():
    filenames = get_request_data("filenames", default="")
    filenames = json.loads(filenames)
    for filename in filenames:
        yield filename


def download_chunks_from_hkex(filename):
    # Set "chunk_size=100000" (in bytes) to improve download speed drastically
    # Using "yield" instead of "return" will result in immediate response,
    # because zip file starts downloading after the first filing is requested
    filing_content = fetch_filing(filename).iter_content(chunk_size=100000)
    for chunk in filing_content:
        yield chunk


@retry(stop_max_attempt_number=5, wait_fixed=3000)
def fetch_filing(filename):
    url = create_url_from_filename(filename)
    # Set "stream=True" for immediate response, without fetching entire filing
    filing = requests.get(url, stream=True)
    return filing


def create_and_clean_up_new_filename(old_name):
    new_name = create_filename(old_name)
    new_name = replace_illegal_characters_with_dash(new_name)
    new_name = unicode(new_name, "utf-8")
    return new_name


def create_filename(old_name):
    # New name looks like this:  2015-01-01_Next Day Disclosure Return.pdf
    id, file_extension = os.path.splitext(old_name)
    YYYY = get_year(id)
    MM = get_month(id)
    DD = get_day(id)
    title = get_and_format_title(id)
    new_name = "{}-{}-{}_{}{}".format(YYYY, MM, DD, title, file_extension)
    return new_name


def replace_illegal_characters_with_dash(filename):
    cleansed_filename = re.sub('[<>:"/\|?*]', '-', filename)  # Replace  <  >  :  /  |  ?  *
    return cleansed_filename


def get_and_format_title(id):
    # max_length is restricted to 100 for safety, because Chinese characters takes up 3 bytes
    # Too-long filenames will corrupt the zipfile
    title = get_shortened_title(id, max_length=70)
    title = titlecase(title)
    return title
