# coding=utf8
import arrow
from flask import g, request, url_for
from . import main
from .. import constants as C
from ..language import _
from ..util import get_request_data, switch_language

@main.app_context_processor
def inject_context_into_template():
    return dict(len=len, str=str, arrow=arrow, C=C, _=_, switch_language=switch_language)


@main.before_app_request
def guess_interface_language():
    language_of_prev_session = request.cookies.get(C.LANGUAGE, default=C.ENGLISH)
    g.language = get_request_data(C.LANGUAGE, default=language_of_prev_session)
    if g.language not in [C.ENGLISH, C.CHINESE]:
        g.language = C.ENGLISH


@main.before_app_request
def customize_arrow_locales():
    arrow.locales.EnglishLocale.timeframes["hour"] = "1 hr"
    arrow.locales.EnglishLocale.timeframes["hours"] = "{0} hr"
    arrow.locales.EnglishLocale.timeframes["minute"] = "1 min"
    arrow.locales.EnglishLocale.timeframes["minutes"] = "{0} min"
    arrow.locales.ChineseTWLocale.day_names = ["", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
