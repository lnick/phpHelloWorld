from flask import jsonify, render_template
from flask.ext.login import current_user
from . import watchlist
from .. import exception as e
from .. import constants as C
from ..util import get_request_data, jsonify_exception
from ..stream import render_template_stream
from ..database.query import guess_stock_code, get_stock_name, get_watchlist_row_generator_logged_in, get_watchlist_row_generator_not_logged_in
from ..display.htmlrows import generate_html_rows
from ..searchhistory import SearchHistory

@watchlist.route('/show_watchlist')
def show_watchlist():
    if current_user.is_authenticated:
        row_generator = get_watchlist_row_generator_logged_in()
    else:
        row_generator = get_watchlist_row_generator_not_logged_in()
    rows = generate_html_rows(row_generator)
    search_history = SearchHistory()
    search_history.load_from_cookie()
    return render_template_stream("watchlist.html", rows=rows, search_history=search_history)


@watchlist.route("/add_to_watchlist")
def add_to_watchlist():
    search_phrase = get_request_data("phrase")
    try:
        stock_code = guess_stock_code(search_phrase)
        stock_name = get_stock_name(stock_code)
        current_user.add_to_watchlist(stock_code)
        table_html = render_watchlist_table_html()
        return jsonify(stock_code=stock_code, stock_name=stock_name, table_html=table_html)
    except (e.NoStockCodeFoundError, e.NotYetLoggedInError) as err:
        return jsonify_exception(err)
    except e.StockCodeAlreadyOnWatchlistError as err:
        return jsonify_exception(err, stock_code=stock_code, stock_name=stock_name)


@watchlist.route("/remove_from_watchlist")
def remove_from_watchlist():
    try:
        stock_code = get_request_data("stock_code")
        stock_name = get_stock_name(stock_code)
        current_user.remove_from_watchlist(stock_code)
        return jsonify(stock_code=stock_code, stock_name=stock_name)
    except e.NotYetLoggedInError as err:
        return jsonify_exception(err)
    except e.StockCodeNotOnWatchlistError as err:
        return jsonify_exception(err, stock_code=stock_code, stock_name=stock_name)


@watchlist.route("/toggle_watchlist")
def toggle_watchlist():
    try:
        stock_code = get_request_data("stock_code")
        if current_user.is_watching_stock_code(stock_code):
            current_user.remove_from_watchlist(stock_code)
            return jsonify(action=C.REMOVED)
        else:
            current_user.add_to_watchlist(stock_code)
            return jsonify(action=C.ADDED)
    except e.NotYetLoggedInError as err:
        return jsonify_exception(err)


def render_watchlist_table_html():
    row_generator = get_watchlist_row_generator_logged_in()
    rows = generate_html_rows(row_generator)
    html = render_template("table_watchlist.html", rows=rows)
    return html
