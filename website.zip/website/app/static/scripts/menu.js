"use strict";

$(document).ready(function() {
    focusOnInputBoxOnShowingMenu();
    toggleDimBackgroundOnTogglingMenu();
    collapseMenuOnPressingESC();
    collapseMenuOnClickingOverlayOrNavbar();
});

function focusOnInputBoxOnShowingMenu() {
    // IE wipes the placeholder text of input text box when focused
    // This is undesirable, because user will not know what to do with the input text box
    $("#menu").on("shown.bs.collapse", function () {
        if (!isInternetExplorer()) {
            $(".input-search").focus();
        }
    });
}

function toggleDimBackgroundOnTogglingMenu() {
    $("#menu").on("show.bs.collapse hidden.bs.collapse", function () {
        $("#dim-background").toggle();
    });
}

function collapseMenuOnPressingESC() {
    $(document).keydown(function(e) {
        if (e.which == ESC) {
            $("#menu").collapse("hide");
        }
    });
}

function collapseMenuOnClickingOverlayOrNavbar() {
    $("#dim-background, .navbar-header").click(function () {
        $("#menu").collapse("hide");
    });
}
