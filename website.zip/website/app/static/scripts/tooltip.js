"use strict";

$(document).ready(function() {
    initializeTooltips();
    initializeDynamicTooltips();
});

function initializeTooltips() {
    $(".toolbar .label").tooltip();
    $(".toolbar .download-failed").tooltip();
    $(".checkbox-select-all").tooltip();
}

function initializeDynamicTooltips() {
    // http://stackoverflow.com/a/20867078/4248121
    // http://getbootstrap.com/javascript/#tooltips-options
    $("table").tooltip({
        selector    : "[data-toggle='tooltip']",
        placement   : "bottom",
        html        : "true"
    });
}
