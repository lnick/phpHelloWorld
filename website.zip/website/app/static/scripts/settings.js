"use strict";

$(document).ready(function() {
    enableToggleShowHidePassword();
    enableChangePassword();
    enablePasswordValidator();
    clearFeedbacksOnTyping();
});

function enableToggleShowHidePassword() {
    $("#input-old-password, #input-new-password").hidePassword(true);
}

function enableChangePassword() {
    $("#change-password-form").on("submit", function(e) {
        e.preventDefault();
        requestChangePassword().done(showChangePasswordFeedbacks);
    });
}

function clearFeedbacksOnTyping() {
    $("#input-old-password").on("input", function() {
        turnInputBoxToDefaultState("#input-old-password");
        $("#old-password-validation-feedback").html("&nbsp;");
    });
}

function enablePasswordValidator() {
    var pwValidator = new PasswordValidator();
    pwValidator.validateAsYouType();
}

function requestChangePassword() {
    var data = {
        old_password    : $("#input-old-password").val(),
        new_password    : $("#input-new-password").val()
    }
    return $.post($SCRIPT_ROOT + "/change_password", data);
}

function showChangePasswordFeedbacks(response) {
    if (!response) {
        alertChangedPasswordSuccessfully();
        clearPasswordFields();
    } else if (response.exception == "BadPasswordError") {
        showBadPasswordFeedbacks();
    } else if (response.exception == "InvalidPasswordError") {
        showInvalidPasswordFeedbacks();
    }
}

function alertChangedPasswordSuccessfully() {
    $("#input-old-password, #input-new-password").val();
    var message = _("Changed password successfully");
    showAlert("success", message, GLYPHICON_OK);
}

function clearPasswordFields() {
    $("#input-old-password").val("");
    $("#input-new-password").val("");
}

function showBadPasswordFeedbacks() {
    $("#old-password-validation-feedback").html(_("Old password is wrong!"));
    $("#old-password-validation-feedback").select();
    turnInputBoxToErrorState("#old-password-validation-feedback");
}

function showInvalidPasswordFeedbacks() {
    $("#new-password-validation-feedback").html(_("Please enter a password"));
    $("#new-password-validation-feedback").select();
    turnInputBoxToErrorState("#new-password-validation-feedback");
}
