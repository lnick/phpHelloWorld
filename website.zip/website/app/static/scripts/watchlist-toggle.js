"use strict";

$(document).ready(function() {
    enableWatchlistToggle();
});

function enableWatchlistToggle() {
    $(".btn-toggle-watchlist-add, .btn-toggle-watchlist-remove").on("click", function() {
        // TODO:  use $(".stock-code").text() instead
        var stockCode = $(this).data("stock-code");
        requestToggeWatchlist(stockCode);
    });
}

function requestToggeWatchlist(stockCode) {
    requestToggleStockCode(stockCode).done(renderToggleResponse);
    // TODO:  add fail() callback
}

function requestToggleStockCode(stockCode) {
    var data = {"stock_code" : stockCode};
    return $.get($SCRIPT_ROOT + "/toggle_watchlist", data);
}

function renderToggleResponse(response) {
    if (response.action == "ADDED") {
        showRemoveButton();
        alertSuccessfulAddition();
    } else if (response.action == "REMOVED") {
        showAddButton();
        alertSuccessfulRemoval();
    } else if (response.exception == "NotYetLoggedInError") {
        alertNotYetLoggedIn();
    }
}

function showRemoveButton() {
    $(".btn-toggle-watchlist-add").addClass("hidden");
    $(".btn-toggle-watchlist-remove").removeClass("hidden");
}

function showAddButton() {
    $(".btn-toggle-watchlist-remove").addClass("hidden");
    $(".btn-toggle-watchlist-add").removeClass("hidden");
}

function alertSuccessfulAddition() {
    var message = _("Added to watchlist successfully");
    showAlert("success", message, GLYPHICON_OK);
}

function alertSuccessfulRemoval() {
    var message = _("Removed from watchlist successfully");
    showAlert("success", message, GLYPHICON_OK);
}

function alertNotYetLoggedIn() {
    var language = detectLanguage();
    var signUpLink = "<a href='/sign_up_form?language={}'>{}</a>".format(language, _("Sign up"));
    var loginLink = "<a href='/login_form?language={}'>{}</a>".format(language, _("log in"));
    var message = _("To use watchlist, please log in. {} or {} now").format(signUpLink, loginLink);
    showAlert("warning", message, GLYPHICON_EXCLAMATION);
}
