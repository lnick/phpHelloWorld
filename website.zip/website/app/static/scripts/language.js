"use strict";

var ENGLISH = "E";  // Need to have the same value as ENGLISH in constants.py
var CHINESE = "C";  // Need to have the same value as CHINESE in constants.py

var TRANSLATION = {

    // Sign-up form
    "{} Looks good!"                                : "{} 可以使用!",
    "This email is already registered. {}"          : "這個電郵已被註冊。 {}",
    "Doesn't look like a valid email"               : "不是正確的電郵地址",
    "Please enter an email"                         : "請輸入電郵",
    "Please enter a password"                       : "請輸入密碼",
    "Log in"                                        : "馬上登入",

    // Login form
    "You haven't signed up yet. {}"         : "你仍未註冊。 {}",
    "Wrong password!"                       : "密碼錯誤!",
    "Sign up now"                           : "立即註冊",
    "We've sent you your password"          : "密碼已寄到你的電郵",
    "Unable to send password"               : "發生故障, 無法寄出密碼",

    // Search
    "Cannot find any filings <strong>{}</strong>"   : "<strong>{}</strong> 都沒有公告",
    "Showing filings <strong>{}</strong>"           : "顯示<strong>{}</strong>的公告",
    "in the past year"                              : "過去一年",
    "at all times"                                  : "所有時期",
    "Filtered by label <strong>{}</strong>. {}"     : "只顯示有 <strong>{}</strong> 標籤的公告。{}",
    "Remove filter"                                 : "顯示所有標籤",
    "Removed filter. Showing all labels"            : "顯示所有標籤",
    "Cannot find company"                           : "找不到上市公司",

    // Latest
    "No filings were published in the past 2 days"          : "過去2天沒有新公告",

    // Watchlist
    "Watchlist is empty.  Add stocks now"                   : "監察名單仍是空白。請加入股票",
    "Added <strong>{}</strong> to watchlist"                : "<strong>{}</strong> 已加入監察名單",
    "Removed <strong>{}</strong> from watchlist"            : "<strong>{}</strong> 已從名單移除",
    "<strong>{}</strong> is already on watchlist"           : "<strong>{}</strong> 已在監察名單上",
    "Cannot find company <strong>{}</strong>"               : "找不到上市公司 <strong>{}</strong>",
    "Failed to add <strong>{}</strong> to watchlist"        : "無法加入 <strong>{}</strong>",
    "Failed to remove <strong>{}</strong> from watchlist"   : "無法移除 <strong>{}</strong>",
    "To use watchlist, please log in. {} or {} now"    : "你要登入才能使用監察名單。請 {} 或 {}",
    "Sign up"                                               : "註冊",
    "log in"                                                : "登入",  // Note that "log is lowercase"
    "Added to watchlist successfully"                       : "成功加至監察名單",
    "Removed from watchlist successfully"                   : "已從監察名單移除",

    // Settings
    "Old password is wrong!"                                : "舊密碼不正確!",
    "Changed password successfully"                         : "成功更改密碼"
};

function _(englishText) {
    if (detectLanguage() == CHINESE) {
        return TRANSLATION[englishText];
    } else {
        return englishText;
    }
}
