"use strict";

$(document).ready(function() {
    enableToggleShowHidePassword();
    enableValidators();
    forbidSubmittingFormIfErrors();
});

function enableToggleShowHidePassword() {
    $("#input-new-password").hidePassword(true);
}

function enableValidators() {
    var emailValidator = new EmailValidator();
    var pwValidator = new PasswordValidator();
    emailValidator.validateAsYouType();
    pwValidator.validateAsYouType();
}

function forbidSubmittingFormIfErrors() {
    $("#sign-up-form").on("submit", function(e) {
        $("#sign-up-form input").each( function() {
            if (hasInputError($(this))) {
                e.preventDefault();
            }
        });
    });
}

function hasInputError(inputbox) {
    return inputbox.closest(".form-group").hasClass("has-error");
}
