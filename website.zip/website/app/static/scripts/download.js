"use strict";

$(document).ready(function() {
    enableDownloadAllVisibleFilings();
    enableDownloadSelectedFilings();
    hideDownloadFailureTooltip();
});

function enableDownloadAllVisibleFilings() {
    $(".download-all").click(function() {
        downloadZipFile(getFilenames("tr:visible"));
    });
}

function enableDownloadSelectedFilings() {
    $(".download-selected").click(function() {
        downloadZipFile(getFilenames("tr.selected"));
    });
}

function getFilenames(rows) {
    // rows can either be "tr:visible" or "tr.selected"
    var filenames = []
    $(rows).each(function() {
        var url = $(this).find(".title-col a").prop("href");
        var filename = extractFilename(url);
        filenames.push(filename);
    });
    return filenames
}

function extractFilename(url) {
    // See  http://stackoverflow.com/a/6543254/4248121
    var filename = url.split('/').pop();
    return filename;
}

// Android doesn't support "POST" method download, and therefore cannot download any filings
// https://github.com/johnculviner/jquery.fileDownload/blob/master/src/Scripts/jquery.fileDownload.js
function downloadZipFile(filenames) {
    if (filenames.length > 0) {
        $.fileDownload($SCRIPT_ROOT + "/download_zip_file", {
            data:               {filenames:  JSON.stringify(filenames)},
            httpMethod:         "POST",
            prepareCallback:    function() {prepareDownload()},
            successCallback:    function() {succeedDownload()},
            failCallback:       function() {failDownload()}
        });
    }
}

function prepareDownload() {
    var parameters = {left: "-25px", color: "white", scale: 0.7};
    $('.download').spin(parameters);
    toggleDownloadButtonDisabledState();
}

function succeedDownload() {
    $('.download').spin(false);
    toggleDownloadButtonDisabledState();
}

function failDownload() {
    toggleDownloadButtonDisabledState();
    $('.download').spin(false);
    showDownloadFailureTooltip();
}

function toggleDownloadButtonDisabledState() {
    // This is the idiomatic way to toggle property, "disabled" in this case
    // Recommended by jQuery docs:  http://api.jquery.com/prop/
    $(".download").prop("disabled", function (_, val) {return !val;});
}

function showDownloadFailureTooltip() {
    $(".download-failed").tooltip("show");
}

function hideDownloadFailureTooltip() {
    $(window).on("click keypress resize", function() {
        $(".download-failed").tooltip("hide");
    });
}
