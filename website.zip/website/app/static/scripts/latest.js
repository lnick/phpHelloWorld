"use strict";

$(document).ready(function() {
    alertIfNoFilingFound();
});

function alertIfNoFilingFound() {
    // Also called by enableFilterRowsByLabel in filter.js
    if (!isThereAnyRow()) {
        var message = _("No filings were published in the past 2 days");
        showAlert("warning", message, GLYPHICON_EXCLAMATION);
    }
}
