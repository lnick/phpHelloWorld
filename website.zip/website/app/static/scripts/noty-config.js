$.noty.defaults = {
    theme: "bootstrapTheme",
    template: "<div class='noty_message'>{} <span class='noty_text'></span><div class='noty_close'></div></div>",
    animation: {
        open: {opacity: "toggle"},
        close: {opacity: "show"},
        speed: 300
    },
    killer: true,
    closeWith: [],
    callback: {}
};
