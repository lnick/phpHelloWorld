"use strict";

$(document).ready(function() {
    enableFilterRowsByLabel();
    enableRemoveFilterLink();
});

function enableFilterRowsByLabel() {
    // on() binds events to dynamically created elements
    // http://stackoverflow.com/a/9331127
    $(document).on("click", ".label", function() {
        if (isThisLabelAlreadyFiltered(this)) {
            showAllLabels();
        } else {
            filterRowsByLabel(this);
        }
        alertIfNoFilingFound();
    });
}

function isThisLabelAlreadyFiltered(label) {
    var areSomeOtherLabelsDisabled = !!$(".label-disabled").length;
    var isThisLabelSelected = !$(label).hasClass("label-disabled");
    return areSomeOtherLabelsDisabled && isThisLabelSelected;
}

function showAllLabels() {
    $("tr").removeClass("hidden-row-label");
    $(".label").removeClass("label-disabled");
    alertFilterIsRemoved();
}

function filterRowsByLabel(label) {
    showOnlyRowsByLabelType(label);
    lightUpLabelsOfSameType(label);
    alertFilterIsApplied(label)
}

function showOnlyRowsByLabelType(label) {
    var labelType = getLabelType(label);
    $("tr").addClass("hidden-row-label");
    $("tr").has(labelType).removeClass("hidden-row-label");
}

function lightUpLabelsOfSameType(label) {
    var labelType = getLabelType(label);
    $(".label").addClass("label-disabled");
    $(labelType).removeClass("label-disabled");
}

function getLabelType(label) {
    // Returns selector string in the format of ".label-******".  Example:  .label-danger
    var labelClasses = $(label).prop("class");
    var labelModifierClass = labelClasses.split(" ")[1];
    return "." + labelModifierClass;
}

function alertFilterIsApplied(label) {
    if (isThereAnyVisibleRow()) {
        var labelText = $(label).text().trim();
        var showAllLink = '<a class="remove-filter" href="javascript:void(0);">{}</a>'.format(_("Remove filter"));
        var message = _("Filtered by label <strong>{}</strong>. {}").format(labelText, showAllLink);
        showAlert("success", message, GLYPHICON_INFO)
    }
}

function enableRemoveFilterLink() {
    $(document).on("click", ".remove-filter", function(e) {
        e.preventDefault();
        showAllLabels();
    });
}

function alertFilterIsRemoved() {
    if (isThereAnyVisibleRow()) {
        showAlert("success", _("Removed filter. Showing all labels"), GLYPHICON_INFO)
    }
}

function alertIfNoFilingFound() {
    // Do not delete
    // To be implemented in choose-period.js and latest.js
}
