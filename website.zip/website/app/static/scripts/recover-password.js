"use strict";

$(document).ready(function() {
    enablePasswordRecoveryForm();
    enablePasswordRecoveryLinkOnSettingsPage();
    clearFeedbacksOnTyping();
});

function enablePasswordRecoveryForm() {
    $("#password-recovery-form").on("submit", function(e) {
        e.preventDefault();
        var email = $("#input-email").val();
        requestSendPassword(email).done(showSendPasswordFeedbacks);
    });
}

function enablePasswordRecoveryLinkOnSettingsPage() {
    $("#password-recovery-link").on("click", function() {
        var email = $("#email").html();
        requestSendPassword(email)
            .done(showSendPasswordFeedbacks)
            .fail(alertUnableToSendPassword);
    });
}

function clearFeedbacksOnTyping() {
    $("#input-email").on("input", function() {
        turnInputBoxToDefaultState("#input-email");
        $("#email-feedback").html("&nbsp;");
    });
}

function requestSendPassword(email) {
    // TODO:  add a spinner
    var language = detectLanguage();
    var data = {email : email, language : language};
    return $.get($SCRIPT_ROOT + "/send_password", data);
}

function showSendPasswordFeedbacks(response) {
    $.noty.closeAll();
    if (!response) {
        alertSentPassword();
    } else if (response.exception == "NoSuchUserError") {
        showNoSuchUserFeedbacks();
    }
}

function alertSentPassword() {
    showAlert("success", _("We've sent you your password"), GLYPHICON_OK);
}

function showNoSuchUserFeedbacks() {
    var message = createNoSuchUserMessage()
    $("#email-feedback").html(message);
    $("#input-email").select();
    turnInputBoxToErrorState("#input-email");
}

function createNoSuchUserMessage() {
    var encodedEmail = encodeURIComponent($("#input-email").val());
    var language = detectLanguage();
    var signUpLink = "<a href='/sign_up_form?language={}&email={}'>{}</a>".format(language, encodedEmail, _("Sign up now"))
    var message = _("You haven't signed up yet. {}").format(signUpLink);
    return message;
}

function alertUnableToSendPassword() {
    showAlert("error", _("Unable to send password"), GLYPHICON_EXCLAMATION);
}
