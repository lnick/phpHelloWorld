"use strict";

$(document).ready(function() {
    $(".spinner").spin();
    requestOlderRows().done(appendRowsToTable);
});

function requestOlderRows() {
    var stockCode = $(".stock-code").text();
    var data = {"stock_code" : stockCode};
    return $.get($SCRIPT_ROOT + "/search_show_older", data);
}

function appendRowsToTable(response) {
    $("table tr:last").after(response);
    enableShowMoreLink();
}

function enableShowMoreLink() {
    if (areSomeRowsOlderThanOneYear()) {
        $(".show-older-link-wrapper").removeClass("invisible");
    } else {
        $(".show-older-link-wrapper").remove();
    }
}

function areSomeRowsOlderThanOneYear() {
    return $("tr.old").size() > 0;
}
