"use strict";

$(document).ready(function() {
    initializeWatchlistUI();
    enableAddToWatchlist();
    enableRemoveFromWatchlist();
    alertEmptyWatchlist();
});

function initializeWatchlistUI() {
    clearAndFocusOnInputBox();
    toggleLoadingState(false);
    $("tr").show();
    $(".label").removeClass("label-disabled");
    $("#only-past-month").toggle(isThereAnyRow());
}

function enableAddToWatchlist() {
    $("#watchlist-form").on("submit", function(e) {
        e.preventDefault();
        addToWatchlist();
    });
}

function enableRemoveFromWatchlist() {
    $(document).on("click", ".remove-from-watchlist", function(e) {
        var stockCode = $(this).closest("[data-stock-code]").data("stock-code");
        removeFromWatchlist(stockCode);
    });
}

function addToWatchlist() {
    var phrase = $("#input-add-to-watchlist").val();
    toggleLoadingState(true);
    requestNewWatchlist(phrase)
        .done(renderAdditionResponse)
        .fail(function() {alertFailedAddition(phrase)})
        .always(initializeWatchlistUI);
}

function alertEmptyWatchlist() {
    if (!isThereAnyRow()) {
        var message = _("Watchlist is empty.  Add stocks now");
        showAlert("information", message, GLYPHICON_INFO);
    }
}

function requestNewWatchlist(phrase) {
    var data = {phrase : phrase};
    return $.get($SCRIPT_ROOT + "/add_to_watchlist", data);
}

function renderAdditionResponse(response) {
    if (response.table_html) {
        renderNewWatchlist(response);
    } else if (response.exception == "StockCodeAlreadyOnWatchlistError") {
        alertAlreadyOnWatchlist(response);
        highlightAddedRows(response);
    } else if (response.exception == "NoStockCodeFoundError") {
        alertNoSuchStock();
    } else if (response.exception == "NotYetLoggedInError") {
        alertNotYetLoggedIn();
    }
}

function renderNewWatchlist(response) {
    $("tr").remove();
    $("table").html(response.table_html);
    highlightAddedRows(response);
    alertSuccessfulAddition(response);
    initializeTooltip();    // TODO:  find a different to binds tooltip to dynamically created elements
}

function highlightAddedRows(response) {
    var rowSelector = "tr[data-stock-code='{}']".format(response.stock_code);
    $(rowSelector).addClass("highlight-fade-in");   // TODO:  remove animation after showing once
}

function removeFromWatchlist(stockCode) {
    requestRemoveFromDatabase(stockCode)
        .done(renderRemoveResponse)
        .fail(function() {alertFailedRemoval(stockCode)})
        .always(initializeWatchlistUI);
}

function requestRemoveFromDatabase(stockCode) {
    var data = {stock_code : stockCode};
    return $.get($SCRIPT_ROOT + "/remove_from_watchlist", data);
}

function renderRemoveResponse(response) {
    if (response.stock_code) {
        removeRowsFromDOM(response);
        alertSuccessfulRemoval(response);
    } else if (response.exception == "NotYetLoggedInError") {
        alertNotYetLoggedIn();
    }
}

function removeRowsFromDOM(response) {
    var rowSelector = "tr[data-stock-code='{}']".format(response.stock_code);
    $(rowSelector).fadeOut("fast");
    $(rowSelector).remove();
}

function alertSuccessfulAddition(response) {
    var stock = format_stock(response);
    var message = _("Added <strong>{}</strong> to watchlist").format(stock);
    showAlert("success", message, GLYPHICON_OK);
}

function alertSuccessfulRemoval(response) {
    var stock = format_stock(response);
    var message = _("Removed <strong>{}</strong> from watchlist").format(stock);
    showAlert("success", message, GLYPHICON_OK);
}

function alertAlreadyOnWatchlist(response) {
    var stock = format_stock(response);
    var message = _("<strong>{}</strong> is already on watchlist").format(stock);
    showAlert("information", message, GLYPHICON_INFO);
}

function alertNoSuchStock() {
    var phrase = $("#input-add-to-watchlist").val();
    var message = _("Cannot find company <strong>{}</strong>").format(phrase);
    showAlert("error", message, GLYPHICON_EXCLAMATION);
}

function alertFailedAddition(phrase) {
    // TODO:  add "try again" link to alert box
    var message = _("Failed to add <strong>{}</strong> to watchlist").format(phrase);
    showAlert("error", message, GLYPHICON_EXCLAMATION);
}

function alertFailedRemoval(stockCode) {
    // TODO:  add "try again" link to alert box
    var message = _("Failed to remove <strong>{}</strong> from watchlist").format(stockCode);
    showAlert("error", message, GLYPHICON_EXCLAMATION);
}

function alertNotYetLoggedIn() {
    var language = detectLanguage();
    var signUpLink = "<a href='/sign_up_form?language={}'>{}</a>".format(language, _("Sign up"));
    var loginLink = "<a href='/login_form?language={}'>{}</a>".format(language, _("log in"));
    var message = _("To use watchlist, please log in. {} or {} now").format(signUpLink, loginLink);
    showAlert("error", message, GLYPHICON_EXCLAMATION);
}

function format_stock(response) {
    return "{} ({})".format(response.stock_name, response.stock_code);
}

function clearAndFocusOnInputBox() {
    $("#input-add-to-watchlist").val("");
    $("#input-add-to-watchlist").focus();
}

function toggleLoadingState(toTurnOnLoadingState) {
    toggleSpinner(toTurnOnLoadingState);
    toggleButtonDisabledState(toTurnOnLoadingState);
}

function toggleSpinner(toTurnOnLoadingState) {
    if (toTurnOnLoadingState) {
        var parameters = {left: "-25px", color: "black", scale: 0.7};
        $("#watchlist-form .input-group-btn").spin(parameters);  //#watchlist-form .input-group
    } else {
        $("#watchlist-form .input-group-btn").spin(false);
    }
}

function toggleButtonDisabledState(toTurnOnLoadingState) {
    $("#btn-add-to-watchlist").prop("disabled", toTurnOnLoadingState);
}
