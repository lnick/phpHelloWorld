"use strict";

$(document).ready(function() {
    enableLogout();
});

function enableLogout() {
    $(".logout").on("click", function() {
        $.ajax({
            url:  $SCRIPT_ROOT + "/logout",
            statusCode: {
                204: function() { location.reload() },
            }
        });
    });
}
