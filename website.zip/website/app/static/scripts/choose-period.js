"use strict";

$(document).ready(function() {
    enableChoosePeriodMenu();
    alertIfNoFilingFound();
});

function enableChoosePeriodMenu() {
    $(document).on("click", "#menu-choose-period, .show-older-link-wrapper", function(e) {
        swapChoosePeriodText();
        $("tr.old").toggleClass("hidden-old");
        $(".show-older-link-wrapper").toggle();
        alertChangePeriod();
        alertIfNoFilingFound();
    });
}

function alertChangePeriod() {
    if (isThereAnyVisibleRow()) {
        var period = choosePeriod();
        var message = _("Showing filings <strong>{}</strong>").format(period);
        showAlert("success", message, GLYPHICON_INFO);
    }
}

function alertIfNoFilingFound() {
    if (!isThereAnyVisibleRow()) {
        var period = choosePeriod();
        var message = _("Cannot find any filings <strong>{}</strong>").format(period);
        showAlert("warning", message, GLYPHICON_EXCLAMATION);
    }
}

function choosePeriod() {
    return areThereHiddenOlderRows() ? _("in the past year") : _("at all times");
}

function areThereHiddenOlderRows() {
    return $("tr.hidden-old").size() > 0
}

function swapChoosePeriodText() {
    var tmp1 = $("#menu-choose-period .btn-text").text();
    var tmp2 = $("#btn-choose-period .btn-text").text();
    $("#menu-choose-period .btn-text").text(tmp2);
    $("#btn-choose-period .btn-text").text(tmp1);
}
