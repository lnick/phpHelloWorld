"use strict";

$(document).ready(function() {
    enableLogin();
    clearFeedbacksOnTyping();
    fillEmailForEmailRecovery();
});

function enableLogin() {
    $("#login-form").on("submit", function(e) {
        e.preventDefault();
        requestLogin().done(showLoginFeedbacks);
    });
}

function clearFeedbacksOnTyping() {
    $("#login-form input").on("input", function() {
        turnInputBoxToDefaultState("#login-form input")
        $("#login-form label").html("&nbsp;");
    });
}

function fillEmailForEmailRecovery() {
    $("#recover-password-link").on("click", function(e) {
        var language = detectLanguage();
        var email = $("#input-email").val();
        var link = "/recover_password?" + $.param({language:language, email:email});
        $(this).attr("href", link);
    });
}

function requestLogin() {
    var data = {
        email       : $("#input-email").val(),
        password    : $("#input-password").val()
    }
    return $.post($SCRIPT_ROOT + "/login", data);
}

function showLoginFeedbacks(response) {
    if (!response) {
        redirectToWatchlist();
    } else if (response.exception == "NoSuchUserError") {
        showNoSuchUserFeedbacks();
    } else if (response.exception == "BadPasswordError") {
        showBadPasswordFeedbacks();
    }
}

function redirectToWatchlist() {
    var language = detectLanguage();
    window.location = "/show_watchlist?language={}".format(language);
}

function showNoSuchUserFeedbacks() {
    var message = createNotYetSignedUpMessage();
    $("#email-feedback").html(message);
    $("#input-email").select();
    turnInputBoxToErrorState("#input-email");
}

function showBadPasswordFeedbacks() {
    $("#password-feedback").html(_("Wrong password!"));
    $("#input-password").select();
    turnInputBoxToErrorState("#input-password");
}

function createNotYetSignedUpMessage() {
    var encodedEmail = encodeURIComponent($("#input-email").val());
    var language = detectLanguage();
    var signUpLink = "<a href='/sign_up_form?language={}&email={}'>{}</a>".format(language, encodedEmail, _("Sign up now"))
    var message = _("You haven't signed up yet. {}").format(signUpLink);
    return message;
}
