// This file contains ugly workaround code tailored for IE9 or older.
"use strict";

$(document).ready(function() {
    setPlaceholderTextOnInputBox();
});


// IE9 or older doesn't support placeholder text in input box
// This function enables the placeholder workaround in jquery.placeholder.js
// https://github.com/mathiasbynens/jquery-placeholder
function setPlaceholderTextOnInputBox() {
    $("input").placeholder();
}

// Overrides function of the same name in util.js
// IE9 doesn't support matchMedia
// http://stackoverflow.com/a/9410162
function isLargeScreen() {
    var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    return screenWidth > 768;
}
