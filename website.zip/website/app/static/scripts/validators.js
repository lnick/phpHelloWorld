"use strict";

var Validator = function() {
    this.previousRequest = null;

    this.requestValidationAndDisplayResults = function() {
        this.abortPreviousRequest();
        this.previousRequest = this.requestServerValidation().done(this.showValidationResults);
    }

    this.abortPreviousRequest = function() {
        if (this.previousRequest) {
            this.previousRequest.abort();
        }
    }

    this.requestServerValidation = function() {
        var data = {"input" : $(this.inputBox).val()};
        return $.getJSON($SCRIPT_ROOT + this.route, data);
    }

    this.showMessage = function(message) {
        $(this.feedbackLabel).html(message);
    }
}

var EmailValidator = function() {
    Validator.call(this);
    var self = this;
    this.route = "/validate_email"
    this.inputBox = "#input-sign-up-email";
    this.feedbackLabel = "#email-feedback";

    this.validateAsYouType = function() {
        this.validate();
        this.clearFeedbacksOnTyping();
    }

    this.validate = function() {
        $(self.inputBox).on("blur", function() {
            self.requestValidationAndDisplayResults();
        });
    }

    this.clearFeedbacksOnTyping = function() {
        $(self.inputBox).on("input", function() {
            self.clearFeedbacks();
        });
    }

    this.clearFeedbacks = function() {
        $(self.feedbackLabel).html("&nbsp;");  // "&nbsp;" prevents jumping of elements beneath it
        $(self.inputBox).closest(".form-group").removeClass("has-success has-error");
    }

    this.showValidationResults = function(response) {
        if (!response) {
            self.showGoodEmailFeedbacks();
        } else if (response.exception == "EmailSyntaxError") {
            self.showInvalidEmailSyntaxFeedbacks();
        } else if (response.exception == "EmailEmptyError") {
            self.showEmptyEmailFeedbacks();
        } else if (response.exception == "EmailAlreadyTakenError") {
            self.showEmailAlreadyTakenFeedbacks();
        }
    }

    this.showGoodEmailFeedbacks = function() {
        self.showMessage(_("{} Looks good!").format(GLYPHICON_OK));
        turnInputboxToSuccessState(self.inputBox);
    }

    this.showInvalidEmailSyntaxFeedbacks = function() {
        self.showMessage(_("Doesn't look like a valid email"));
        turnInputBoxToErrorState(self.inputBox);
    }

    this.showEmptyEmailFeedbacks = function() {
        self.showMessage(_("Please enter an email"));
        turnInputBoxToErrorState(self.inputBox);
    }

    this.showEmailAlreadyTakenFeedbacks = function() {
        var message = self.createEmailAlreadyTakenMessage();
        self.showMessage(message);
        turnInputBoxToErrorState(self.inputBox);
    }

    this.createEmailAlreadyTakenMessage = function() {
        var language = detectLanguage();
        var email = $("#input-sign-up-email").val();
        var link = "/login_form?" + $.param({language:language, email:email});
        var loginLink = "<a href='{}'>{}</a>".format(link, _("Log in"))
        var message = _("This email is already registered. {}").format(loginLink);
        return message;
    }
};


var PasswordValidator = function() {
    Validator.call(this);
    var self = this;
    this.inputBox = "#input-new-password";
    this.feedbackLabel = "#new-password-validation-feedback";

    this.validateAsYouType = function() {
        $(self.inputBox).on("input", function() {
            self.validateInputAndGiveFeedbacks();
        });
    }

    this.validateInputAndGiveFeedbacks = function() {
        var password = $(self.inputBox).val();
        if (password) {
            self.showGoodPasswordFeedbacks();
        } else {
            self.showNoPasswordFeedbacks();
        }
    }

    this.showGoodPasswordFeedbacks = function() {
        self.showMessage(_("{} Looks good!").format(GLYPHICON_OK));
        turnInputboxToSuccessState(self.inputBox);
    }

    this.showNoPasswordFeedbacks = function () {
        self.showMessage(_("Please enter a password"));
        turnInputBoxToErrorState(self.inputBox);
    }
};
