"use strict";

$(document).ready(function() {
    clearInputBoxOnGoBack();
    blurInputBoxOnTypingESCKey();
});

function clearInputBoxOnGoBack() {
    $(window).bind("pageshow", function() {
        $("input").val();
    });
}

function blurInputBoxOnTypingESCKey() {
    $(document).keydown(function(e) {
        if (e.which == ESC) {
            $("input").blur();
        }
    });
}
