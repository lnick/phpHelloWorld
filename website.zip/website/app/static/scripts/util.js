"use strict";

var XHR = null;

var ESC = 27;
var GLYPHICON_OK            = "<span class='glyphicon glyphicon-ok'></span> "
var GLYPHICON_EXCLAMATION   = "<span class='glyphicon glyphicon-exclamation-sign'></span> "
var GLYPHICON_INFO          = "<span class='glyphicon glyphicon-info-sign'></span> "

// Copied from http://stackoverflow.com/a/4974690
// Javascript implementation of Python's format() function
// e.g. "My name is {}".format("Alpha")  ===>  "My name is Alpha"
String.prototype.format = function () {
  var i = 0, args = arguments;
  return this.replace(/{}/g, function () {
    return typeof args[i] != 'undefined' ? args[i++] : '';
  });
};

function detectLanguage() {
    return $("input[name='language']").val();
}

function isInternetExplorer() {
    // Modified based on http://stackoverflow.com/a/21712356/4248121
    // Tested on Chrome, Firebox and IE 11
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf('MSIE ');
    var trident = ua.indexOf('Trident/');
    var edge = ua.indexOf('Edge/');
    var isIE = (msie > 0 || trident > 0 || edge > 0);
    return isIE;
}

function isLargeScreen() {
    // 768px is the Bootstrap standard for medium-sized screen
    // Not supported by IE9 or below.  Overridden in old_ie_workaround.js
    return window.matchMedia && window.matchMedia("(min-width: 768px)").matches;
}

function isThereAnyRow() {
    return $("tr").size() > 0;
}

function isThereAnyVisibleRow() {
    return $("tr:visible").size() > 0;
}

function showAlert(alertType, message, glyphiconClass) {
    $.noty.closeAll();
    var alert = $(".alert-anchor").noty({
        type:     alertType,
        text:     message,
        template: $.noty.defaults.template.format(glyphiconClass)
    });
}

function turnInputboxToSuccessState(selector) {  // TODO:  implement as static class
    $(selector).closest(".form-group").addClass("has-success");
    $(selector).closest(".form-group").removeClass("has-error");
}

function turnInputBoxToErrorState(selector) {  // TODO:  implement as static class
    $(selector).closest(".form-group").addClass("has-error");
    $(selector).closest(".form-group").removeClass("has-success");
}

function turnInputBoxToDefaultState(selector) {  // TODO:  implement as static class
    $(selector).closest(".form-group").removeClass("has-error has-success");
}

function abortEarlierXHR() {
    if (XHR && XHR.readyState != 4) {    // http://stackoverflow.com/a/4551178
        XHR.abort();
    }
 }
