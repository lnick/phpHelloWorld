"use strict";

$(document).ready(function() {
    enableSelectAllCheckbox();
    enableFullRowSelection();
    disableRowSelectionOnClickingTitleOrLabel();
    checkSelectAllBoxIfAllRowsSelectedManually();
    hideSelectAllBoxIfNoRows();
    enableHideSelectAllBoxIfNoRows();
    enableButtonToDownloadAllFilings();
    enableButtonToDownloadSelectedFilings();
});

function enableSelectAllCheckbox() {
    $(".checkbox-select-all").click(function () {
        $("tr:visible").toggleClass("selected", this.checked);
        $("input[type='checkbox']:visible").prop("checked", this.checked);
    });
}

function enableFullRowSelection() {
    $(document).on("click", ".table-selectable tr", function() {
        if (isLargeScreen()) {
            $(this).toggleClass("selected");
            $(this).find("input[type='checkbox']").prop("checked", $(this).hasClass("selected"));
        }
    });
}

function disableRowSelectionOnClickingTitleOrLabel() {
    // See http://stackoverflow.com/a/14162290/4248121
    $(document).on("click", "tr .label, .title-col a", function(e) {
      e.stopPropagation();
    });
}

function checkSelectAllBoxIfAllRowsSelectedManually() {
    $(document).on("click", "tr, a", function(e) {
        var areAllVisibleRowsSelected = $("tr:visible").not(".selected").length == 0;
        $(".checkbox-select-all").prop("checked", areAllVisibleRowsSelected);
    });
}

function enableHideSelectAllBoxIfNoRows() {
    $(document).on("click", "a", function(e) {
        hideSelectAllBoxIfNoRows();
    });
}

function hideSelectAllBoxIfNoRows() {
    $(".checkbox-select-all").toggle(isThereAnyVisibleRow());
}

function enableButtonToDownloadAllFilings() {
    $(".download").click(function() {
        $(".download-all").parent().toggleClass("disabled", !isThereAnyVisibleRow());
    });
}

function enableButtonToDownloadSelectedFilings() {
    $(".download").click(function() {
        var isNoRowSelected = (getFilenames("tr.selected").length == 0);
        $(".download-selected").parent().toggleClass("disabled", isNoRowSelected);
    });
}
