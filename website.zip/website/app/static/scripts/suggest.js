"use strict";

$(document).ready(function() {
    enableSuggestions();
    forbidSearchOnError();
});

$(window).on("click resize scroll", function() {
    $(".has-suggestions").autocomplete("close");
});

function forbidSearchOnError() {
    $(".search-form").on("submit", function(e) {
        if ($(".search-form").hasClass("has-error")) {
            e.preventDefault();
        }
    });
}

function enableSuggestions() {
    // TODO:  Handle 全型 characters for input boxes
    var parameters = {
        delay: 50,
        source: getSuggestionsByAjax,
        search: resetSearchForm,
        response: addCannotFindCompanyLabel,
        select: submitSearchForm
    }
    $(".has-suggestions").autocomplete(parameters);
    $(".has-suggestions").each(function() {
        $(this).data("ui-autocomplete")._renderItem = renderSuggestions;  // http://stackoverflow.com/a/3490609
    });
}

function resetSearchForm(event, ui) {
    $(this).closest("form").removeClass("has-error");
    $(this).siblings("button:submit").prop("disabled", false);
}

function submitSearchForm(event, ui) {
    $(this).val(ui.item.value);  // Submit form correctly when clicking menu item.  See http://goo.gl/EQKGcM
    if (ui.item.value) {
        $(this).closest("form").submit();
    }
}

function getSuggestionsByAjax(request, response) {
    abortEarlierXHR();
    var data = {phrase: request.term, language: detectLanguage()};
    XHR = $.getJSON($SCRIPT_ROOT + "/suggest", data, response);
}

function addCannotFindCompanyLabel(event, ui) {
    if (ui.content.length == 0) {
        $(this).closest("form").addClass("has-error");
        $(this).siblings("button:submit").prop("disabled", false);
        ui.content.push({});
    }
}

function renderSuggestions(ul, item) {
    if (item.value) {
        return renderListItems(this.term, ul, item);
    } else {
        return showNoResultsFound(this.term, ul, item);
    }
}

function renderListItems(term, ul, item) {
    var stockCode = highlightSearchResult(term, item.value);
    var stockName = highlightSearchResult(term, item.label);
    var template = "<span class='stock-code-suggestion-menu'>{}</span>{}";
    var menuListItem = template.format(stockCode, stockName);
    return $("<li></li>").data("item.autocomplete", item).append(menuListItem).appendTo(ul);
}

function showNoResultsFound(term, ul, item) {
    var template = "<span class='text-danger'>{} <em>\"{}\"</em></span>";
    var noResultsFound = template.format(_("Cannot find company"), term);
    return $("<li class='no-company-found'></li>").data("item.autocomplete", item).append(noResultsFound).appendTo(ul);
}

function highlightSearchResult(term, result) {
    term = term.toUpperCase().replace(/^[0]+/g,"");   // Trim leading zeroes
    var template = "<span class='highlighted-search-term'>{}</span>"
    var highlightedTerm = template.format(term);
    var highlightedResult = result.toString().replace(term, highlightedTerm);
    return highlightedResult;
}
