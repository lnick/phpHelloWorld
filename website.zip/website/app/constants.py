import datetime

DOMAIN = "localhost"

STOCK_CODES = "stock_codes"

# Request argument names
PHRASE = "phrase"
LANGUAGE = "language"

CHINESE = "C"
ENGLISH = "E"

SEARCH_HISTORY = "search_history"

# HKEX started its Electronic Disclosure Project on 2007-06-25
EDP_EFFECTIVE_DATE = datetime.datetime(2007, 6, 25, 0, 0)

EMAIL_MAX_LENGTH = 256
PASSWORD_MAX_LENGTH = 30

ADDED = "ADDED"
REMOVED = "REMOVED"
