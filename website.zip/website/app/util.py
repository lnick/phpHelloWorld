import sys
import arrow
import requests
from urllib import urlencode
from urlparse import urlparse, parse_qsl, ParseResult
from flask import request, current_app, jsonify
from sqlalchemy.sql import text
from webassets.filter import Filter
import mysql.connector


class HTMLMinifier(Filter):
    name = "htmlmin"
    def output(self, _in, out, **kwargs):
        html = _in.read()
        html = html.splitlines()
        html = [line.strip() for line in html]
        html = "".join(html)
        out.write(html)


def allow_utf8_in_source_code():
    reload(sys)
    sys.setdefaultencoding("utf-8")


def get_request_data(key, default=None):
    value = None
    if request.method == "GET":
        value = request.args.get(key, default)
    elif request.method == "POST":
        value = request.form.get(key, default)
    return value


def jsonify_exception(error, **kwargs):
    return jsonify(exception=type(error).__name__, **kwargs)


def fetch_all(command):
    connection = create_mysql_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(command)
    rows = cursor.fetchall()
    connection.close()
    return rows


def execute_and_commit(command):
    connection = create_mysql_connection()
    cursor = connection.cursor()
    cursor.execute(command)
    cursor.close()
    connection.commit()
    connection.close()


def generate_mysql_rows(command):
    connection = create_mysql_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(command)
    while True:
        # Set "size=25" because a browser can normally display ~25 rows "above the fold"
        rows = cursor.fetchmany(size=25)
        if not rows:
            break
        for row in rows:
            yield row


def create_mysql_connection():
    logins = current_app.config["MYSQL_LOGIN_CREDENTIALS"]
    return mysql.connector.connect(**logins)


def send_email(to_address, from_address, subject, body_html):
    mailgun_url = current_app.config["MAILGUN_API_URL"]
    auth = ("api", current_app.config["MAILGUN_API_KEY"])
    data = {"from": from_address, "to": [to_address], "subject": subject, "html": body_html}
    return requests.post(mailgun_url, auth=auth, data=data)


def one_year_later():
    return arrow.utcnow().replace(days=+365).naive


def switch_language(url, language):
    parsed_url = urlparse(url)
    args = parsed_url.query
    parsed_args = dict(parse_qsl(args))
    parsed_args.update({"language": language})
    encoded_args = urlencode(parsed_args)
    new_url = parsed_url.path + "?" + encoded_args
    return new_url
