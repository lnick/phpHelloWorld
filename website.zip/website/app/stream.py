from flask import Response, g, render_template, stream_with_context, current_app
import constants as C
from util import one_year_later


def create_error_response(error_msg):
    return render_template("error.html", error_msg=error_msg)


def render_template_stream(template_name, **context):
    template_stream = stream_template(template_name, **context)
    template_stream = stream_with_context(template_stream)
    response = Response(template_stream)
    response = add_language_cookie(response)
    return response


def stream_template(template_name, **context):
    current_app.update_template_context(context)
    template = current_app.jinja_env.get_template(template_name)
    template_stream = template.stream(context)
    template_stream.enable_buffering(5)
    return template_stream


def add_language_cookie(response):
    response.set_cookie(C.LANGUAGE, str(g.language), expires=one_year_later())
    return response
