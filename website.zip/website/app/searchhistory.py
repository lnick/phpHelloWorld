from functools import wraps
from collections import deque
import json
from flask import request
import constants as C
from util import one_year_later

class SearchHistory():

    def __init__(self):
        self.stock_codes = deque(maxlen=10)

    def get_stock_codes_for_mysql(self):
        return str(list(self.stock_codes)).strip("[]")

    def create_new_cookie(self, stock_code):
        self.load_from_cookie()
        self.add_stock_code(stock_code)
        return self.serialize()

    def load_from_cookie(self):
        cookie_string = request.cookies.get(C.SEARCH_HISTORY, default=deque([]))
        if cookie_string:
            cookie_list = json.loads(cookie_string)
            self.stock_codes = deque(cookie_list, maxlen=10)

    def add_stock_code(self, stock_code):
        if stock_code in self.stock_codes:
            self.stock_codes.remove(stock_code)
        self.stock_codes.append(stock_code)

    def serialize(self):
        return json.dumps(list(self.stock_codes))

    @staticmethod
    def add_search_history_cookie(f):
        @wraps(f)
        def decorator(stock_code):
            history = SearchHistory()
            stock_codes_cookie = history.create_new_cookie(stock_code)
            response = f(stock_code)
            response.set_cookie(C.SEARCH_HISTORY, stock_codes_cookie, expires=one_year_later())
            return response
        return decorator
