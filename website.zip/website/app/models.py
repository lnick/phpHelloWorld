from flask import request
from flask.ext.login import UserMixin, AnonymousUserMixin
from flask.ext.sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import NoResultFound
from email_validator import validate_email, EmailSyntaxError
import exception as e
import constants as C
from util import get_request_data

db = SQLAlchemy()


class Watch(db.Model):
    __tablename__ = "watchlist"
    __table_args__ = (db.UniqueConstraint("user_id", "stock_code"),)
    watch_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    stock_code = db.Column(db.Integer)

    def __repr__(self):
        return "<Watch %r, user_id=%r, stock_code=%r>" %(self.watch_id, self.user_id, self.stock_code)


class User(db.Model, UserMixin):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(254), unique=True)
    password = db.Column(db.String(128))
    watchlist = db.relationship("Watch", backref="watch")

    def __repr__(self):
        return "<User %r, %r>" %(self.id, self.email)

    def check_password(self, password):
        if password != self.password:
            raise e.BadPasswordError

    @classmethod
    def get_user_by_email(cls, email):
        user = User.query.filter_by(email=email).first()
        if not user:
            raise e.NoSuchUserError
        return user

    @classmethod
    def get_user_by_id(cls, id):
        user = User.query.filter_by(id=id).first()
        if not user:
            raise e.NoSuchUserError
        return user

    @classmethod
    def create_account(cls, new_user):
        db.session.add(new_user)
        db.session.commit()

    @classmethod
    def validate_user_data(cls, email, password):
        User.validate_email(email)
        User.check_if_email_is_already_taken(email)
        User.validate_password(password)

    @classmethod
    def validate_email(cls, email):
        if not email:
            raise e.EmailEmptyError
        validate_email(email, check_deliverability=False)

    @classmethod
    def check_if_email_is_already_taken(cls, email):
        user = User.query.filter_by(email=email).first()
        if user:
            raise e.EmailAlreadyTakenError

    @classmethod
    def validate_password(cls, password):
        if password == "":
            raise e.InvalidPasswordError("password cannot be empty")
        if len(password) > C.PASSWORD_MAX_LENGTH:
            raise e.InvalidPasswordError("Password is too long")

    def change_password(self, new_password):
        self.password = new_password
        db.session.commit()

    def add_to_watchlist(self, stock_code):
        try:
            watch = Watch(user_id=self.id, stock_code=int(stock_code))
            db.session.add(watch)
            db.session.commit()
        except IntegrityError as err:
            db.session.rollback()
            if "Duplicate entry" in err.message:
                raise e.StockCodeAlreadyOnWatchlistError
        except ValueError:
            raise e.NoStockCodeFoundError

    def remove_from_watchlist(self, stock_code):
        try:
            watch = Watch.query.filter_by(user_id=self.id, stock_code=int(stock_code)).one()
            db.session.delete(watch)
            db.session.commit()
        except (NoResultFound, ValueError):
            db.session.rollback()
            raise e.StockCodeNotOnWatchlistError

    def is_watching_stock_code(self, stock_code):
        try:
            is_watching = int(stock_code) in [watch.stock_code for watch in self.watchlist]
            return is_watching
        except:
            return False


class AnonymousUser(AnonymousUserMixin):

    def add_to_watchlist(self, stock_code):
        raise e.NotYetLoggedInError

    def remove_from_watchlist(self, stock_code):
        raise e.NotYetLoggedInError

    def is_watching_stock_code(self, stock_code):
        raise e.NotYetLoggedInError
