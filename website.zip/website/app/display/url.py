def create_url_for_row(row):
    filename = row["id"] + "." + row["file_type"]
    row["url"] = create_url_from_filename(filename)

    
def create_url_from_filename(filename):
    # url looks like this: http://www.hkexnews.hk/listedco/listconews/sehk/2015/0505/LTN201505051345_C.pdf
    exchange = "SEHK" if "LTN" in filename else "GEM"
    YYYY = get_year(filename)
    MMDD = get_month(filename) + get_day(filename)
    url = "http://www.hkexnews.hk/listedco/listconews/%s/%s/%s/%s" %(exchange, YYYY, MMDD, filename)
    return url
    

def get_year(filename):
    YYYY = filename[3:7]
    return YYYY


def get_month(filename):
    MM = filename[7:9]
    return MM


def get_day(filename):
    DD = filename[9:11]
    return DD