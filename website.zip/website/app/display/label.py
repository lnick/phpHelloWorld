# coding=utf8
from flask import g
from .. import constants as C
from ..language import _

def label_row(row):
    row["is_trivial"] = is_trivial(row)
    row["labels"] = detect_labels(row)
    row["is_cancelled"] = is_cancelled(row)


def detect_labels(row):
    labels = []
    if is_attention(row):
        labels.append(_("attention"))
    if is_corporate_action(row):
        labels.append(_("corp action"))
    if is_personnel(row):
        labels.append(_("personnel"))
    if is_financial(row):
        labels = [_("financial")]
    if row["is_trivial"] or not labels:
        labels = [_("others")]
    return labels


def is_attention(row):
    keywords = {}
    keywords["category"] = {
        "regulatory announcement & news",           "監管者發出的公告及消息" # mostly SFC censure
    }
    keywords["sub_category"] = {
        "trading halt", "suspension",               "停牌",
        "resumption",                               "復牌",
        "auditors",                                 "核數師",
        "accountant",                               "會計師",
        "profit warning",                           "盈利警告",
        "qualified and/or modified audit report",   "保留意見",
        "delay in results announcement",            "延遲發表業績公告",
        "delay in completion",                      "在完成須予公布的交易方面出現延誤",
        "material errors",                          "重大錯誤",
        "litigation",                               "訴訟",
        "breach",                                   "違反",
        "unusual price/turnover movements",         "不尋常",
        "inside information",                       "內幕消息",
        "price-sensitive information",              "股價敏感資料",
        "concentration of shareholdings",           "股權集中",
        "sufficiency of public float",              "公眾持股量充足度"
    }
    if is_published_after_EDP_effective_date(row):
        keywords["title"] = {
            "clarification", "clarifying",          "澄清",
            "disciplinary proceeding",              "紀律研訊",
            "change of shareholding",               "股權變動"
        }
    else:
        keywords["title"] = {
            "breach",                               "違反",
            "movement",                             "不尋常波動",  # unusual price and volume movements
            "suspension",                           "停牌",
            "resumption",                           "復牌"
        }
    return does_match_keywords(row, keywords)


def is_financial(row):
    keywords = {}
    keywords["category"] = {"financial statements", "財務報表"}
    keywords["sub_category"] = {
        "final results",                            "末期業績",
        "interim results",                          "中期業績",
        "quarterly results",                        "季度業績",
        "net asset value",                          "資產淨值",
        "results of a subsidiary",                  "附屬公司的業績",
        "trading update",                           "營運業績最新情況"

    }
    if is_published_after_EDP_effective_date(row):
        keywords["title"] = {
            "fund performance",                     "基金表現",
            "financial statement",                  "財務報",
            "unaudited",                            "未經審核", "未經審計",
            "sales update",                         "銷售簡報",
            "traffic figures",                      "貨運量數據",
            "sales announcement",                   "銷售公告"
        }
    else:
        keywords["title"] = {
            "annual report",                        "年報",
            "interim report",                       "中期報告",
            "quarterly report",                     "季度報告",
            "financial statement",                  "財務報",
            "results announcement",                 "業績",
            "net asset value",                      "資產淨值"
        }
    return does_match_keywords(row, keywords)


def is_corporate_action(row):
    keywords = {}
    keywords["category"] = {
        "takeovers code - dealing disclosures",     "合併守則",
        "phip",                                     "申請版本及聆訊後資料集",
        "share buyback reports",                    "購回報告"
    }
    keywords["sub_category"] = {
        "takeovers code",                           "收購守則",
        "code on share buy-backs",                  "公司股份回購守則",
        "reverse takeover",                         "反收購",
        "share buyback",                            "購回",
        "amendment of constitutional documents",    "修訂憲章文件",
        "dividend or distribution",                 "股息",
        "egm",                                      "股東特別大會",
        "financial assistance",                     "財務資助",
        "advance to an entity",                     "向實體提供墊款",
        "formal notice",                            "正式通告",
        "offer for sale",                           "發售現有證券",
        "spin-off",                                 "分拆",
        "privatisation",                            "私有化",
        "introduction",                             "介紹",
        "share option scheme",                      "購股權計劃",
        "open offer",                               "公開招股",
        "mixed media offer",                        "混合媒介要約",
        "offer for subscription",                   "發售以供認購",
        "rights issue",                             "供股",
        "placing",                                  "配售",
        "scheme of arrangement",                    "協議安排",
        "Issue of Securities and Related Matters",  "證券發行及相關事宜",
        "capital reorganisation",                   "資本重組",
        "capitalisation issue",                     "資本化發行",
        "general mandate",                          "一般性授權",
        "liquidation",                              "清盤",
        "issue of",                                 "發行債務證券", "發行優先股", "發行權證", "發行股份", "發行可轉換證券", "主要附屬公司發行",
        "very substantial", "transaction",          "須予公布的交易", "關連交易", "須予披露的交易", "股份交易", "主要交易", "終止交易", "非常重大"
    }
    if is_published_after_EDP_effective_date(row):
        keywords["title"] = {
            "joint announcement",                   "聯合公告",
            "takeovers code",                       "收購守則",
            "offering circular",                    "發售通函",
            "spin-off",                             "分拆",
            "refinancing", "re-financing",          "再融資",
            "acquisition",                          "收購",
            "disposal",                             "出售",
            "redemption",                           "贖回",
            "share premium account",                "股份溢價賬",
            "share consolidation",                  "股份合併",
            "commercial paper",                     "融資券",
            "extraordinary general meeting", "special general meeting", " egm", " sgm", "特別大會"
        }
    else:
        # TODO:  Label MOUs as "corp action"
        keywords["title"] = {
            "joint announcement",                   "聯合公告",
            "dividend",                             "股息", "中期息",
            "buyback", "repurchase",                "回購", "購回",
            "offer",                                "收購",
            "options", "option scheme",             "購股權",
            "new listing", "prospectus",            "新上市",
            "formal notice",                        "正式通告",
            "transaction",                          "關連交易", "須予公布的交易", "須予公布交易", "關連交易", "須予披露的交易", "須予披露交易", "股份交易", "主要交易", "終止交易", "非常重大",
            "share premium account",                "股份溢價賬",
            "capital reorganisation",               "重組股本", "資本重組",
            "share consolidation",                  "股份合併"
        }
    return does_match_keywords(row, keywords)


def is_personnel(row):
    keywords = {}
    keywords["sub_category"] = {
        "change in directors",                      "更改董事", "更換董事",
        "nomination of director",                   "提名董事",
        "appointment of director",                  "委任董事",
        "change in supervisor",                     "更換監事",
        "company secretary",                        "公司秘書",
        "chief executive",                          "行政總裁",
        "compliance advisor",                       "合規顧問",
        "compliance officer",                       "監察主任",
        "committee member",                         "委員會成員",
        "biographical details",                     "履歷詳情",
        "list of directors",                        "董事名單",
        "change in auditor",                        "更換核數師",
        "change in qualified accountant",           "更換合資格會計師"
    }
    if is_published_after_EDP_effective_date(row):
        keywords["title"] = {"change of director", "董事變更"}
    else:
        keywords["title"] = {"director", "董事"}
    return does_match_keywords(row, keywords)


def is_trivial(row):
    keywords = {}
    keywords["category"] = {
        "monthly returns",                              "月報表",
        "proxy forms",                                  "委任代表表格",
        "company information sheet",                    "公司資料報表",
        "trading information of exchange traded funds", "交易所買賣基金的交易資料"
    }
    keywords["title"] = {
        "proxy form", "form of proxy",              "委任代表表格", "委任表格",
        "notification letter",                      "通知信函",
        "request form", "application form",         "申請表格",
        "election of language",                     "語言版本",
        "terms of reference",                       "職權範圍",
        "reply slip", "reply form",                 "回條", "回覆表格",
        "corporate communications",                 "公司通訊",
        "notice of availability",                   "提供通知"
    }
    return does_match_keywords(row, keywords)


def is_cancelled(row):
    keyword = {"Cancelled", "作廢" ,"取消"}
    return any(k in row["category"] for k in keyword)


def is_published_after_EDP_effective_date(row):
    return row['date_time'] > C.EDP_EFFECTIVE_DATE


def does_match_keywords(row, keywords):
    if does_match_category_keyword(row, keywords):
        return True
    if does_match_sub_category_keyword(row, keywords):
        return True
    if does_match_title_keyword(row, keywords):
        return True


def does_match_category_keyword(row, keywords):
    category = row["category"].lower()
    keyword = keywords.get("category", "")
    return any(k in category for k in keyword)


def does_match_sub_category_keyword(row, keywords):
    sub_category = row["sub_category"].lower()
    keyword = keywords.get("sub_category", "")
    return any(k in sub_category for k in keyword)


def does_match_title_keyword(row, keywords):
    title = row["title"].lower()
    keyword = keywords.get("title", "")
    return any(k in title for k in keyword)
