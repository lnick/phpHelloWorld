from label import label_row
from format import format_row
from url import create_url_for_row
from ..util import generate_mysql_rows

def generate_html_rows(sql_row_generator):
    for row in sql_row_generator:
        label_row(row)
        format_row(row)
        create_url_for_row(row)
        yield row
