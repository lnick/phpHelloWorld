import os
import re
from string import capwords

DICTIONARY_FOLDER = os.path.dirname(os.path.abspath(__file__)) 
ENGLISH_DICTIONARY_PATH = os.path.join(DICTIONARY_FOLDER, "english_us_dictionary.txt")
CUSTOM_DICTIONARY_PATH = os.path.join(DICTIONARY_FOLDER, "custom_dictionary.txt")


def load_dicitionaries_from_file():
    english_us_dictionary = set(line.strip() for line in open(ENGLISH_DICTIONARY_PATH))
    custom_dictionary = set(line.strip() for line in open(CUSTOM_DICTIONARY_PATH))
    combined_dictionary = english_us_dictionary | custom_dictionary
    return combined_dictionary

    
def titlecase(title):
    if original_title_is_uppercase(title):
        words = title.lower().split()
        words = [change_to_proper_case(word) for word in words]
        title = " ".join(words)
        title = capitalize_1st_char(title)
    return title


def original_title_is_uppercase(title):
    lowercase_alphabet_count = sum(1 for alphabet in title if alphabet.islower())
    return lowercase_alphabet_count < 20
    

def change_to_proper_case(word):
    stripped_word = re.sub(",|:|;|\(|\)|'", "", word).lower()
    if should_be_lower_case(stripped_word):
        return word.lower()
    elif is_english_word(stripped_word):
        return capwords(word)
    else:
        return word.upper()

    
def should_be_lower_case(word):
    return is_common_word(word) or is_nth_day_of_month(word)

    
def is_common_word(word):
    REGEX_COMMON_WORDS = "^(an|and|as|at|be|but|by|en|for|if|in|of|on|or|the|to|with)$"
    return re.match(REGEX_COMMON_WORDS, word)


def is_nth_day_of_month(word):
    REGEX_NTH_DAY_OF_MONTH = "^(\\d|\\d\\d)(st|nd|rd|th)$"
    return re.match(REGEX_NTH_DAY_OF_MONTH, word.lower())
        
        
def is_english_word(word):
    chunks = word.split("-")  # Checks if all chunks of a hyphenated word are English
    return all([is_from_dictionary(chunk) for chunk in chunks])


def is_from_dictionary(word):
    return word in DICTIONARY if word else True
    

def capitalize_1st_char(title):
    return title[0].capitalize() + title[1:] if title else ""


DICTIONARY = load_dicitionaries_from_file()