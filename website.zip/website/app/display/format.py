# coding=utf8
import arrow
import re
from flask import g
from .. import constants as C
from ..language import _
from titlecase import titlecase
from multiline import multiline


def format_row(row):
    convert_date_time_to_arrow_object(row)
    change_english_title_to_titlecase(row)
    make_circular_title_readable(row)
    make_buyback_announcements_readable(row)
    show_sub_category_for_uninformative_title(row)
    show_sub_category_for_uninformative_overseas_title(row)
    break_long_title_into_multiple_lines(row)
    # TODO  convert chinese dates


def convert_date_time_to_arrow_object(row):
    row["date_time"] = arrow.get(row["date_time"], "Hongkong")


def make_circular_title_readable(row):
    title = row["title"].strip().lower()
    if row["category"] in ("Circulars", "通函"):
        if "circular" not in title and "通函" not in title:
          row["title"] = row["category"] + " - " + row["title"]


def make_buyback_announcements_readable(row):
    if row["sub_category"] in ("Share Buyback", "股份購回"):
        row["title"] = row["sub_category"] + " - " + row["title"]


def change_english_title_to_titlecase(row):
    if row["language"] == C.ENGLISH:
        row["title"] = titlecase(row["title"])


def break_long_title_into_multiple_lines(row):
    row["title"] = multiline(row["title"], row["language"])


def show_sub_category_for_uninformative_title(row):
    title = row["title"].strip().lower()
    REGEX_UNINFORMATIVE_TITLES = "^(announcement|announcements|circular|circulars|公告|公布|公佈|通函)$"
    if re.match(REGEX_UNINFORMATIVE_TITLES, title) and row["sub_category"]:
        row["title"] = row["title"] + " - " + row["sub_category"].replace(",", ", ")


def show_sub_category_for_uninformative_overseas_title(row):
    title = row["title"].strip().lower()
    if title in ["overseas regulatory announcement", "海外監管公告"] and row["sub_category"]:
        row["sub_category"] = row["sub_category"].replace("Overseas Regulatory Announcement -", " ")
        row["sub_category"] = row["sub_category"].replace("海外監管公告-", " ")
        row["title"] = row["title"] + " - " + row["sub_category"]
