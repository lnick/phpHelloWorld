# coding=utf8
import re
from .. import constants as C

def multiline(title, language):
    if is_title_long_enough_to_multiline(title, language):
        title = add_newline_after_colon_semicolon_or_dash(title)
        title = add_newline_before_ordered_bullet_point(title)
        title = add_newline_before_and_after_long_text_in_parentheses(title)
        title = eliminate_multiple_newline(title)
        title = eliminate_beginning_newline(title)
    return title


def is_title_long_enough_to_multiline(title, language):
    if language == C.ENGLISH:
        return len(title) > 100
    else:
        return len(title) > 30


def add_newline_after_colon_semicolon_or_dash(title):
    # u"XXX" to denote utf8 pattern
    title = re.sub(u"(; and)|(；(以|)及)|;|；|:|：| - | / ", add_new_line_after, title)
    return title


def add_newline_before_ordered_bullet_point(title):
    title = re.sub("\\s\\([1-9]\\)", add_newline_before, title)
    title = re.sub("\\s\\([A-Ja-j]\\)", add_newline_before, title)
    title = re.sub("\\s\\((i|ii|iii|iv|v|vi|vii|viii|ix|x)\\)", add_newline_before, title)
    title = re.sub("\\s\\((I|II|III|IV|V|VI|VII|VIII|IX|X)\\)", add_newline_before, title)
    return title


def add_newline_before_and_after_long_text_in_parentheses(title):
    title = re.sub("\\([^\\)]{50,}\\)", add_newline_before, title)
    title = re.sub("\\([^\\)]{50,}\\)", add_new_line_after, title)
    return title


def eliminate_multiple_newline(title):
    return re.sub("(<br>)+(\s)*(<br>)+", "<br>", title)


def eliminate_beginning_newline(title):
    title = title.strip()
    title = re.sub("^(<br>)", "", title)
    return title


def add_new_line_after(match):
    return match.group(0) + "<br>"


def add_newline_before(match):
    return "<br>" + match.group(0)
