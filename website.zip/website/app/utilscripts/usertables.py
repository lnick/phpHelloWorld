from ..models import db, User, Watch


def create_user_data_tables():

    db.drop_all()
    db.create_all()

    u1 = User(email="j@gmail.com", password="whisky1")
    u2 = User(email="m@gmail.com", password="whisky2")
    u3 = User(email="b@gmail.com", password="whisky3")
    u4 = User(email="brianlwh@gmail.com", password="nokiaapple")

    w1 = Watch(user_id=1, stock_code=2)
    w2 = Watch(user_id=1, stock_code=6)
    w3 = Watch(user_id=2, stock_code=26)
    w4 = Watch(user_id=2, stock_code=271)
    w5 = Watch(user_id=3, stock_code=939)
    w6 = Watch(user_id=3, stock_code=1398)

    db.session.add_all([u1, u2, u3, u4, w1, w2, w3, w4, w5, w6])
    db.session.commit()
