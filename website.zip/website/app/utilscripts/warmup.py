import logging
from flask import g
from .. import constants as C
from ..util import create_mysql_connection, fetch_all
from ..database.query import get_search_row_generator


LOGGING_CONFIG = {
    "format"    : "%(asctime)s | %(message)s",
    "datefmt"   : "%Y-%m-%d %H:%M",
    "level"     : "INFO"
}

def warm_up_mysql_server():
    create_mysql_connection()
    for stock_code in range(8999, 0, -1):
        for g.language in [C.ENGLISH, C.CHINESE]:
            warm_up_stock_code(stock_code)
            log_message_on_screen(stock_code)


def warm_up_stock_code(stock_code):
    generator = get_search_row_generator(stock_code)
    for row in generator:
        pass


def log_message_on_screen(stock_code):
    logging.basicConfig(**LOGGING_CONFIG)
    message = "Warmed up stock code {0} in {1}".format(stock_code, g.language)
    logging.info(message)
