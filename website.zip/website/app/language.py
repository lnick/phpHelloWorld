# coding=utf8
from flask import g
import constants as C

TRANSLATION = {

    C.CHINESE        : C.ENGLISH,
    "中文"            : "English",
    "顯示中文版"       : "Switch to English",

    # Home page
    "Search & download HKEx filings painlessly"     : "輕鬆搜尋和下載香港上市公司公告",
    "Start here"                                    : "開始",
    "Search company name or stock code"             : "搜尋公司名稱 或 股票代號",
    "Search listed company"                         : "搜尋上市公司",
    "e.g. "                                         : "例如:",

    # Navbar
    "Home"                                          : "主頁",
    "My watchlist"                                  : "我的監察名單",
    "Latest filings"                                : "最新公告",  # Don't remove space after "filings"
    "Sign up"                                       : "建立用戶",
    "Log in"                                        : "登入",
    "Settings"                                      : "設定",
    "Log out"                                       : "登出",

    # Sign up page
    "to create "                                    : "免費建立個人化的",
    "your own watchlist"                            : "監察名單",
    ", for free"                                    : "",
    "Step"                                          : "步驟",
    "Create an account for free"                    : "免費建立用戶",
    "Add stocks to watchlist"                       : "將股票加入監察名單",
    "Email"                                         : "電郵",
    "That's for logging in.  We won't spam you!"    : "用作登入。我們不會濫發廣告!",
    "Password"                                      : "密碼",
    "Pick any password you like"                    : "沒有任何限制",
    "Sign up securely"                              : "安全建立用戶",
    "Email <em>{0}</em> is already registered"      : "電郵地址 <em>{0}</em> 已被註冊",
    "<em>{0}</em> doesn't look like a valid email"  : "<em>{0}</em> 不是正確的電郵地址",
    "Email cannot be empty"                         : "電郵地址不能空白",
    "{} Email cannot be empty"                      : "{} 電郵地址不能空白",
    "Password cannot be empty"                      : "密碼不能空白",
    "Log into existing account"                     : "登入現有用戶",
    "Success"                                       : "成功建立用戶",
    "Add stocks to my watchlist now"                : "將股票加入監察名單",
    "Your account <strong>{0}</strong> has been created" :
    "你的登入名稱是 <strong>{0}</strong>",


    # Login page
    "My account"                                    : "我的賬戶",
    "Forgot password"                               : "忘記密碼",
    "Send password to me"                           : "將密碼發到我的電郵",
    "Your password at filingHK.com"                 : "filingHK.com密碼提示",
    "Password reminder"                             : "密碼提示",
    "You requested for your password at {0}."       : "你曾要求收取 {0} 的密碼。",
    "Log into my account now"                       : "馬上登入",
    "Login email"                                   : "你登記的電郵",
    "Enter your email"                              : "請輸入電郵地址",
    "We'll send you your password"                  : "我們會把密碼發到你的電郵",

    # Toolbar
    "All latest filings"                            : "所有最新公告",
    "Search Hong Kong-listed company filings:"      : "搜尋香港上市公司公告：",
    "Select all below"                              : "選擇以下全部",
    "Past year"                                     : "過去1年",
    "All time"                                      : "所有時期",
    "show older..."                                 : "顯示更早期的公告...",
    "Download .zip file"                            : "下載.zip檔",
    "Download"                                      : "下載",
    "Selected only"                                 : "已選取公告",
    "Everything below"                              : "以下全部",

    # Tooltip text
    "HKT"           : "香港時間",
    "Select all"    : "選擇全部",

    "● insider information<br>● trading halt & resumption<br>● profit warning<br>● other unusual events" :
    "● 內幕消息<br>● 停牌及復牌<br>● 盈利警告<br>● 其他特殊情況",

    "● dividend & buyback<br>● acquisition & disposal<br>● takeover<br>● issue of new securities<br>● other corporate actions" :
    "● 股息及回購<br>● 購買及出售資產<br>● 企業併購<br>● 發行證券<br>● 其他企業行動<br>",

    "● financial reports<br>● result announcements<br>● operational statistics" :
    "● 財務報告<br>● 業績公佈<br>● 營運數據",

    "Changes in:<br>● directors<br>● senior management" :
    "董事及管理層之變更",

    # Labels
    "Show all"          : "全部分類",
    "Show all labels"   : "顯示全部分類",
    "corp action"       : "企業行動",
    "attention"         : "注意",
    "financial"         : "財務",
    "personnel"         : "人員",
    "others"            : "其他",
    "Cancelled"         : "作廢",
    "Chinese only"      : "只有英文",

    # Search results
    "with Dividend Distribution"                                    : "及派發股息",
    "The company submitted a wrong document, and revoked it later"  : "公司刊登錯誤的文件，已經作廢",
    "This is an overseas regulatory filing."                        : "這是海外監管公告。",
    "The company hasn't published an English version"               : "公司沒有刊登中文版",

    # Latest page
    "past 2 days"                                                   : "過去2天",

    # Error messages
    "Sorry, cannot find company <em>{}</em>"                    : "抱歉，找不到上市公司 <em>{}</em>",
    "Sorry, page not found"                                     : "抱歉，找不到網頁",
    "Sorry, something went wrong with our site."                : "抱歉，網站發生故障",
    "You can try to:"                                           : "你可以試試：",
    "Go to"                                                     : "前往",
    "home page"                                                 : "主頁",
    "Enter another stock code in the search box"                : "在上面輸入並搜尋另一個股票代號",
    "Try to enter another stock code in the search box above."  : "試在上面輸入並搜尋另一個股票代號。",
    "No filing is labelled"                                     : "沒有公告屬於分類",
    "Try to click another label above."                         : "試在上面選擇其他標籤。",
    "Download failed. Try again."                               : "下載失敗。請重試",

    # Watchlist
    "demo"                                                      : "示範",
    "Sign up to create your customized watchlist"               : "建立個人化的監察名單",
    "Get started"                                               : "建立用戶",
    "Below is a demo,"                                          : "示範",
    "based on your recent searches"                             : "——顯示你最近搜尋的公司：",
    "using stock codes 1, 2 and 3"                              : "——顯示股票代號1, 2及3：",
    "Enter company name or stock code"                          : "輸入公司名稱或股票代號",
    "Enter stock code or name"                                  : "輸入公司名稱或股票代號",
    "Add to watchlist"                                          : "加入監察名單",
    "Added to watchlist"                                        : "已加入監察名單",
    "Remove"                                                    : "移除",  # used in toggle button
    "remove"                                                    : "移除",  # used in watchlist table
    "Only filings in past 30 days are shown on watchlist"       : "只顯示最近30日的公告",

    # Settings
    "Change password"                                           : "更改密碼",
    "Old password"                                              : "舊密碼",
    "New password"                                              : "新密碼",
    "Update password"                                           : "更新密碼",
    "I forgot my password. Send me my password now"             : "我忘記了密碼。請將密碼寄到我的電郵"
}

def _(original_text):
    # Templates are in unicode (e.g. \u4e2d\u6587).   Need to encode in utf-8 first
    original_text = original_text.encode("utf-8")
    if g.language == C.ENGLISH:
        return original_text
    else:
        return TRANSLATION[original_text]
