import json
from flask import g, request
from flask.ext.login import current_user
from sqlalchemy import text
from .. import exception as e
from .. import constants as C
from ..models import db
from ..util import fetch_all, generate_mysql_rows
from ..searchhistory import SearchHistory
import sql


def get_stock_name(stock_code):
    command = sql.STOCK_NAME.format(language())
    row = db.engine.execute(text(command), stock_code=stock_code).first()
    if row:
        return row[0]
    else:
        raise e.NoStockNameFoundError


def get_suggestions(phrase):
    # TODO:  test corner-case inputs
    clean_phrase = make_input_phrase_safe_for_mysql(phrase)
    command = sql.SUGGESTION.format(language(), clean_phrase)
    suggestions = fetch_all(command)
    return suggestions


def guess_stock_code(phrase):
    try:
        clean_phrase = make_input_phrase_safe_for_mysql(phrase)
        command = text(sql.GUESS_STOCK_CODE.format(clean_phrase))
        row = db.engine.execute(command).first()
        return row[0]
    except TypeError:
        raise e.NoStockCodeFoundError


def get_shortened_title(id, max_length):
    command = sql.SHORTENED_TITLE.format(max_length, id)
    rows = fetch_all(command)
    title = rows[0]["title"]
    if len(title) == max_length:
        return title + "~"
    else:
        return title


def get_latest_row_generator():
    command = sql.LATEST.format(max_or_min(), language())
    rows =  generate_mysql_rows(command)
    return rows


def get_search_row_generator(stock_code, get_first_30_rows):
    language = 0 if g.language == C.ENGLISH else 1
    limit_range = "30" if get_first_30_rows else "30, 100000"
    command = sql.SEARCH.format(max_or_min(), language, stock_code, limit_range)
    rows =  generate_mysql_rows(command)
    return rows


def get_watchlist_row_generator_logged_in():
    command = sql.WATCHLIST_LOGGED_IN.format(max_or_min(), language(), current_user.id)
    rows = generate_mysql_rows(command)
    return rows


def get_watchlist_row_generator_not_logged_in():
    history = load_search_history()
    stock_codes = history if history else "1, 2, 3"  # 1, 2, 3 are demo stock codes
    command = sql.WATCHLIST_NOT_LOGGED_IN.format(max_or_min(), stock_codes, language())
    rows = generate_mysql_rows(command)
    return rows


def load_search_history():
    history = SearchHistory()
    history.load_from_cookie()
    return history.get_stock_codes_for_mysql()


def make_input_phrase_safe_for_mysql(phrase):
    return phrase.strip().replace('"', '').lstrip("0")


def max_or_min():
    return "min" if g.language == C.ENGLISH else "max"


def language():
    return "english" if g.language == C.ENGLISH else "chinese"
