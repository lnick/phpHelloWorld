# coding=utf8

STOCK_NAME = """
    SELECT stock_name
    FROM stock_name_{0}
    WHERE stock_code=:stock_code
    LIMIT 1
"""


SHORTENED_TITLE = """
    SELECT LEFT(title, {0}) as title
    FROM filing
    WHERE id='{1}'
    LIMIT 1
"""

GUESS_STOCK_CODE = """
    SELECT
        stock_name_english.stock_code
    FROM
        stock_name_english LEFT JOIN stock_name_chinese
    ON
        stock_name_english.stock_code = stock_name_chinese.stock_code
    WHERE
        stock_name_english.stock_code LIKE "{0}%"
        OR stock_name_chinese.stock_name LIKE "%{0}%"
        OR stock_name_english.stock_name LIKE "%{0}%"
    ORDER BY stock_code
    LIMIT 1;
"""


SUGGESTION = """
    SELECT
        stock_name_{0}.stock_name AS label,
        stock_name_english.stock_code AS value
    FROM
        stock_name_english LEFT JOIN stock_name_chinese
    ON
        stock_name_english.stock_code = stock_name_chinese.stock_code
    WHERE
        (stock_name_english.stock_code LIKE "{1}%"
        OR stock_name_chinese.stock_name LIKE "%{1}%"
        OR stock_name_english.stock_name LIKE "%{1}%")
        AND stock_name_english.stock_code < 9999       # to exclude warrants
    ORDER BY stock_name_english.stock_code
    LIMIT 6;
"""


LATEST = """
    SELECT
        id,
        stock_code,
        stock_name,
        if(subquery.language, "C", "E") as language,
        date_time,
        title,
        category,
        GROUP_CONCAT(sub_category) as sub_category,
        file_type
    FROM
        ( SELECT
            stock_code,
            date_time,
            {0}(language) as language
        FROM
            filing
            NATURAL JOIN stock
        WHERE
            date_time >= (CURDATE() - INTERVAL 48 HOUR)
            AND title NOT RLIKE 'chinese section|英文版面'
        GROUP BY date_time, stock_code
        ) AS subquery
        NATURAL JOIN filing
        NATURAL JOIN stock
        NATURAL JOIN sub_category
        NATURAL JOIN stock_name_{1}
    WHERE
        stock_code < 9999
        AND category NOT RLIKE "Proxy Forms|Company Information Sheet|Monthly Returns|Trading Information of Exchange Traded Funds|Takeovers Code - dealing disclosures|委任代表表格|公司資料報表|月報表|交易所買賣基金的交易資料|合併守則 - 交易披露"
    GROUP BY id
    ORDER BY date_time DESC
"""


SEARCH = """
    SELECT
        id,
        if(subquery.language, "C", "E") as language,
        date_time,
        title,
        category,
        GROUP_CONCAT(sub_category) as sub_category,
        file_type
    FROM
        ( SELECT
            date_time,
            if(date_time >= "2007-06-25", {0}(language), {1}) as language
        FROM
            filing
            NATURAL JOIN stock
        WHERE
            stock_code = {2}
            AND title NOT RLIKE "chinese section|英文版面"
        GROUP BY date_time
        ) AS subquery
        NATURAL JOIN filing
        NATURAL JOIN stock
        NATURAL JOIN sub_category
    WHERE stock_code = {2}
    GROUP BY id
    ORDER BY date_time DESC
    LIMIT {3}
"""


WATCHLIST_LOGGED_IN = """
    SELECT
        id,
        stock_code,
        stock_name,
        if(subquery.language, "C", "E") as language,
        date_time,
        title,
        category,
        GROUP_CONCAT(sub_category) as sub_category,
        file_type
    FROM
        ( SELECT
            stock_code,
            date_time,
            {0}(language) as language
        FROM
            filing NATURAL JOIN stock
        WHERE
            date_time >= (CURDATE() - INTERVAL 30 DAY)
            AND title NOT RLIKE 'chinese section|英文版面'
        GROUP BY date_time, stock_code
        ) AS subquery
        NATURAL JOIN filing
        NATURAL JOIN stock
        NATURAL JOIN sub_category
        NATURAL JOIN stock_name_{1}
        NATURAL JOIN watchlist
    WHERE user_id = {2}
    GROUP BY id
    ORDER BY date_time DESC
"""

WATCHLIST_NOT_LOGGED_IN = """
    SELECT
        id,
        stock_code,
        stock_name,
        if(subquery.language, "C", "E") as language,
        date_time,
        title,
        category,
        GROUP_CONCAT(sub_category) as sub_category,
        file_type
    FROM
        ( SELECT
            stock_code,
            date_time,
            {0}(language) as language
        FROM
            filing NATURAL JOIN stock
        WHERE
            stock_code IN ({1})
            AND date_time >= (CURDATE() - INTERVAL 30 DAY)
            AND title NOT RLIKE 'chinese section|英文版面'
        GROUP BY date_time, stock_code
        ) AS subquery
        NATURAL JOIN filing
        NATURAL JOIN stock
        NATURAL JOIN sub_category
        NATURAL JOIN stock_name_{2}
    GROUP BY id
    ORDER BY date_time DESC
"""
