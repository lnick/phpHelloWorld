class NoStockCodeFoundError(Exception):
    pass

class NoStockNameFoundError(Exception):
    pass

class StockCodeAlreadyOnWatchlistError(Exception):
    pass

class StockCodeNotOnWatchlistError(Exception):
    pass

class NoSuchUserError(Exception):
    pass

class BadPasswordError(Exception):
    pass

class NotYetLoggedInError(Exception):
    pass

class EmailAlreadyTakenError(Exception):
    pass

class EmailEmptyError(Exception):
    pass

class InvalidPasswordError(Exception):
    pass

class NoSearchHistoryError(Exception):
    pass
