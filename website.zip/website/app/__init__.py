from flask import Flask
from flask.ext.migrate import Migrate
from flask.ext.assets import Environment
from webassets.filter import register_filter
from util import allow_utf8_in_source_code, HTMLMinifier
from models import db, AnonymousUser

allow_utf8_in_source_code()

def create_app(config):
    app = Flask(__name__, static_url_path="/app", template_folder="static/templates")
    app.config.from_object(config)

    # http://flask.pocoo.org/docs/0.10/patterns/appfactories/
    db.init_app(app)

    # http://stackoverflow.com/a/29882346
    migrate = Migrate()
    migrate.init_app(app, db)

    from auth.views import login_manager
    login_manager.init_app(app)
    login_manager.anonymous_user = AnonymousUser

    assets = Environment(app)
    register_filter(HTMLMinifier)

    from main import main as main_blueprint
    from auth import auth as auth_blueprint
    from watchlist import watchlist as watchlist_blueprint
    app.register_blueprint(main_blueprint)
    app.register_blueprint(auth_blueprint)
    app.register_blueprint(watchlist_blueprint)

    return app
