Please refer to this page for more information about Neo4j:
http://neo4j.org
