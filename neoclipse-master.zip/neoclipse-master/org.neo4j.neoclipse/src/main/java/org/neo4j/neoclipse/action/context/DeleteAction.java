/**
 * Licensed to Neo Technology under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Neo Technology licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.neo4j.neoclipse.action.context;

import org.neo4j.neoclipse.action.AbstractGraphAction;
import org.neo4j.neoclipse.action.Actions;
import org.neo4j.neoclipse.graphdb.GraphDbUtil;
import org.neo4j.neoclipse.view.Dialog;
import org.neo4j.neoclipse.view.NeoGraphViewPart;

/**
 * Action to delete a node or relationship.
 * 
 * @author Anders Nawroth
 */
public class DeleteAction extends AbstractGraphAction
{
    public DeleteAction( final NeoGraphViewPart neoGraphViewPart )
    {
        super( Actions.DELETE, neoGraphViewPart );
        setEnabled( false );
    }

    @Override
    public void run()
    {
        int count = graphView.getCurrentSelectedNodes().size()
                    + graphView.getCurrentSelectedRels().size();
        if ( count < 1 )
        {
            Dialog.openError( "Delete", "No items are selected." );
            return;
        }
        if ( !GraphDbUtil.confirmDelete( count ) )
        {
            return;
        }
        GraphDbUtil.deletePropertyContainers(
                graphView.getCurrentSelectedRels(), graphView );
        GraphDbUtil.deletePropertyContainers(
                graphView.getCurrentSelectedNodes(), graphView );
        graphView.refreshPreserveLayout();
    }
}
