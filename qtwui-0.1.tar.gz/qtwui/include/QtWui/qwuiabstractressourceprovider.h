#include "../../src/http/qwuiabstractressourceprovider.h"
