#include "../../src/kernel/qwuifileressource.h"
