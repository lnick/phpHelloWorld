#include "../../src/kernel/qwuiapplicationcreator.h"
