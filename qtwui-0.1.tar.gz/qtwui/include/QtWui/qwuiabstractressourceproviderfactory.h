#include "../../src/http/qwuiabstractressourceproviderfactory.h"
