#include "../../src/kernel/qwuifileressourceprovider.h"
