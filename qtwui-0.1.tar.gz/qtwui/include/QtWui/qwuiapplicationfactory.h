#include "../../src/kernel/qwuiapplicationfactory.h"
