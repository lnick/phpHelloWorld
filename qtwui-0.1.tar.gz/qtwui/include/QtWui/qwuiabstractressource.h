#include "../../src/http/qwuiabstractressource.h"
