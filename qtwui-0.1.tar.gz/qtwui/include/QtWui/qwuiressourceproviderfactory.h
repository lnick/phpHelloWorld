#include "../../src/http/qwuiressourceproviderfactory.h"
