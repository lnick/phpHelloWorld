#include "../../src/kernel/qwuiparameters.h"
