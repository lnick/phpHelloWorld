#include "../../src/kernel/qwuibufferedressource.h"
